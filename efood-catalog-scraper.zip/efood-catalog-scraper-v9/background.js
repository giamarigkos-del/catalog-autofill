// background.js — Service Worker (MV3)
// Hub για privileged operations: screenshot, Claude API, interceptor injection

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // ── Screenshot ──────────────────────────────────────────
  if (msg.type === 'takeScreenshot') {
    chrome.tabs.captureVisibleTab(
      sender.tab?.windowId ?? chrome.windows.WINDOW_ID_CURRENT,
      { format: 'jpeg', quality: 50 },
      (dataUrl) => {
        if (chrome.runtime.lastError) {
          sendResponse({ error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ base64: dataUrl.split(',')[1] });
        }
      }
    );
    return true;
  }

  // ── Claude API (no CORS from service worker) ────────────
  if (msg.type === 'claudeCall') {
    const { system, messages, maxTokens } = msg;
    console.log('[efood bg] claudeCall start, maxTokens:', maxTokens);

    fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: maxTokens || 1500,
        system,
        messages
      })
    })
    .then(r => {
      console.log('[efood bg] Claude response status:', r.status);
      return r.json();
    })
    .then(data => {
      console.log('[efood bg] Claude response ok, content length:', data.content?.length);
      sendResponse({ ok: true, data });
    })
    .catch(e => {
      console.error('[efood bg] Claude error:', e.message);
      sendResponse({ ok: false, error: e.message });
    });
    return true; // ΚΡΙΣΙΜΟ: πρέπει να επιστρέψει true για async response
  }

  // ── Interceptor injection μέσω chrome.scripting (bypasses CSP) ──
  if (msg.type === 'injectInterceptor') {
    const tabId = sender.tab?.id;
    if (!tabId) { sendResponse({ error: 'no tab id' }); return true; }

    chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: () => {
        if (window.__efoodIC2) return { alreadyActive: true };
        window.__efoodIC2 = true;
        window.__efoodIntercepted = window.__efoodIntercepted || [];
        window.__efoodPendingRequests = 0;

        const cap = window.__efoodIntercepted;
        const mRx = /menu|catalog|product|item|categor|assortment|food|price|meal|dish|restaurant|shop|store/i;
        const sRx = /analytics|tracking|pixel|gtm|facebook|google-analytics|hotjar|\.png|\.jpg|\.css|woff|font|svg/i;

        const _f = window.fetch;
        window.fetch = async function(...a) {
          const url = (typeof a[0] === 'string' ? a[0] : a[0]?.url) || '';
          if (mRx.test(url) && !sRx.test(url)) window.__efoodPendingRequests = (window.__efoodPendingRequests || 0) + 1;
          const r = await _f.apply(this, a);
          try {
            if (mRx.test(url) && !sRx.test(url)) {
              const cl = r.clone(), ct = cl.headers.get('content-type') || '';
              if (ct.includes('json')) cl.json().then(d => {
                const sz = JSON.stringify(d).length;
                if (sz > 100 && sz < 800000) cap.push({ url, method: 'GET', size: sz, ts: Date.now(), data: d });
                window.__efoodPendingRequests = Math.max(0, (window.__efoodPendingRequests || 1) - 1);
              }).catch(() => { window.__efoodPendingRequests = Math.max(0, (window.__efoodPendingRequests || 1) - 1); });
            }
          } catch(e) { window.__efoodPendingRequests = Math.max(0, (window.__efoodPendingRequests || 1) - 1); }
          return r;
        };

        const _o = XMLHttpRequest.prototype.open;
        const _s = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.open = function(m, u, ...r) { this.__u = u; this.__m = m; return _o.apply(this, [m, u, ...r]); };
        XMLHttpRequest.prototype.send = function(...a) {
          const url = this.__u || '';
          if (mRx.test(url) && !sRx.test(url)) window.__efoodPendingRequests = (window.__efoodPendingRequests || 0) + 1;
          this.addEventListener('load', function() {
            try {
              if (mRx.test(url) && !sRx.test(url) && this.responseText) {
                const d = JSON.parse(this.responseText), sz = this.responseText.length;
                if (sz > 100 && sz < 800000) cap.push({ url, method: this.__m || 'GET', size: sz, ts: Date.now(), data: d });
              }
            } catch(e) {}
            window.__efoodPendingRequests = Math.max(0, (window.__efoodPendingRequests || 1) - 1);
          });
          this.addEventListener('error', () => { window.__efoodPendingRequests = Math.max(0, (window.__efoodPendingRequests || 1) - 1); });
          return _s.apply(this, a);
        };

        return { injected: true };
      }
    })
    .then(results => sendResponse({ ok: true, result: results?.[0]?.result }))
    .catch(e => {
      console.error('[efood bg] inject error:', e.message);
      sendResponse({ ok: false, error: e.message });
    });
    return true;
  }

});
