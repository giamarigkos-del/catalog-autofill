async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function detectPlatform(url) {
  if (!url) return 'unknown';
  if (url.includes('wolt.com')) {
    // /venue/ στο path = Wolt Retail (φαρμακεία, σούπερ μάρκετ κλπ)
    return url.includes('/venue/') ? 'woltRetail' : 'wolt';
  }
  if (url.includes('box.gr')) return 'box';
  if (url.startsWith('http')) return 'standalone';
  return 'unknown';
}

let scrapingTabId = null;
let scrapingWinId = null;

async function runScraper() {
  const tab = await getCurrentTab();
  const btn = document.getElementById('run-btn');
  const stopBtn = document.getElementById('stop-btn');
  const status = document.getElementById('status');
  const platform = detectPlatform(tab.url || '');

  btn.disabled = true;
  btn.textContent = '⏳ Εκκίνηση...';
  status.textContent = 'Φορτώνω scraper...';

  try {
    if (platform === 'woltRetail') {
      // Wolt Retail: ανοίγουμε νέο παράθυρο με zoom 25% για γρήγορο scraping
      stopBtn.style.display = 'flex';

      const win = await chrome.windows.create({
        url: tab.url,
        type: 'normal',
        state: 'maximized'
      });
      scrapingWinId = win.id;

      // Βρίσκουμε το tab του νέου παραθύρου
      const [newTab] = await chrome.tabs.query({ windowId: win.id });
      scrapingTabId = newTab.id;

      // Περιμένουμε να φορτώσει η σελίδα ΠΡΩΤΑ — μετά zoom
      await new Promise(resolve => {
        chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
          if (tabId === scrapingTabId && info.status === 'complete') {
            chrome.tabs.onUpdated.removeListener(listener);
            resolve();
          }
        });
      });

      // Zoom 25% ΜΕΤΑ το load — αλλιώς "Cannot zoom a tab in disabled mode"
      await chrome.tabs.setZoom(scrapingTabId, 0.25);

      // Άλλο 1 δευτ. για να σταθεροποιηθεί το React
      await new Promise(r => setTimeout(r, 1000));

      status.textContent = '🔵 Wolt Retail — τρέχει...';

      await chrome.scripting.executeScript({
        target: { tabId: scrapingTabId },
        func: () => { window.__efoodScraping = false; window.__efoodStop = false; }
      });
      await chrome.scripting.executeScript({
        target: { tabId: scrapingTabId },
        files: ['scraper.js']
      });

      // Polling: περιμένουμε το scraper να τελειώσει
      status.textContent = '🔵 Scraping σε εξέλιξη...';
      btn.textContent = '⏳ Τρέχει...';

    } else {
      // Wolt restaurants, Box, Standalone: τρέχει στο τρέχον tab
      if (platform !== 'unknown') stopBtn.style.display = 'flex';

      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => { window.__efoodScraping = false; window.__efoodStop = false; }
      });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['scraper.js']
      });
      status.textContent = '✓ Τρέχει! Δες τη σελίδα.';
      btn.textContent = '✓ Εκκινήθηκε';
      setTimeout(() => window.close(), 1500);
    }
  } catch (e) {
    status.textContent = '❌ Σφάλμα: ' + e.message;
    btn.disabled = false;
    btn.textContent = '▶ Εκκίνηση εξαγωγής';
    stopBtn.style.display = 'none';
  }
}

async function stopScraper() {
  const tab = await getCurrentTab();
  const status = document.getElementById('status');
  const stopBtn = document.getElementById('stop-btn');
  const btn = document.getElementById('run-btn');

  try {
    // Στέλνουμε το STOP flag στο tab που τρέχει ο scraper
    const targetTabId = scrapingTabId || tab.id;
    await chrome.scripting.executeScript({
      target: { tabId: targetTabId },
      func: () => { window.__efoodStop = true; }
    });
    status.textContent = '⏹ Σταματάω... (αποθηκεύω μερικά δεδομένα)';
    stopBtn.disabled = true;
    stopBtn.textContent = '⏳ Σταματάω...';
  } catch (e) {
    status.textContent = '⚠ Δεν μπόρεσα να σταματήσω: ' + e.message;
    stopBtn.style.display = 'none';
    btn.disabled = false;
    btn.textContent = '▶ Εκκίνηση εξαγωγής';
  }
}

// ── TIMESTAMP για popup (Europe/Athens) ──
function formatTimestamp(date) {
  return date.toLocaleString('el-GR', {
    timeZone: 'Europe/Athens',
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hour12: false
  }).replace(',', '');
}

function formatFilename(date) {
  const parts = date.toLocaleString('el-GR', {
    timeZone: 'Europe/Athens',
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: false
  });
  return parts.replace(', ', '_').replace(/\//g, '-').replace(':', '-');
}

// ── DIAGNOSTIC ──
async function runDiagnostic() {
  const tab = await getCurrentTab();
  const status = document.getElementById('status');
  const diagBtn = document.getElementById('diag-btn');
  const platform = detectPlatform(tab.url || '');

  if (platform !== 'woltRetail') {
    status.textContent = '⚠ Άνοιξε πρώτα ένα Wolt venue';
    return;
  }

  diagBtn.disabled = true;
  diagBtn.textContent = '⏳ Τρέχει...';
  status.textContent = 'Τρέχω diagnostic...';

  try {
    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async () => {
        const startTime = Date.now();

        // DOM checks
        const cards    = document.querySelectorAll('[data-test-id="ItemCard"]');
        const navLinks = document.querySelectorAll('[data-test-id="navigation-bar-link"]');
        const titles   = document.querySelectorAll('[data-test-id="ImageCentricProductCard.Title"]');

        const itemIds = [];
        cards.forEach(card => {
          const href = card.querySelector('a[href*="itemid"]')?.href || '';
          const m = href.match(/itemid-([a-f0-9]+)/);
          if(m) itemIds.push(m[1]);
        });

        // Token check
        let token = null, tokenValid = false, tokenExpiry = null;
        try {
          const raw = document.cookie.split(';').map(c=>c.trim())
            .find(c=>c.startsWith('__wtoken='))?.split('=')?.[1];
          if(raw) {
            const obj = JSON.parse(decodeURIComponent(raw));
            token = obj.accessToken || null;
            tokenValid = !!token;
            // JWT exp (μέσο segment)
            if(token) {
              const payload = JSON.parse(atob(token.split('.')[1]));
              tokenExpiry = payload.exp ? new Date(payload.exp * 1000).toISOString() : null;
            }
          }
        } catch(e) {}

        const slug = location.pathname.match(/\/venue\/([^/?#]+)/)?.[1] || null;

        // Assortment API check (3 τυχαία IDs)
        let apiStatus = null, apiItems = [], apiError = null;
        let hasIdField = false, hasGtinField = false, hasDescField = false;
        const testIds = itemIds.slice(0, 3);

        if(slug && token && testIds.length > 0) {
          try {
            const resp = await fetch(
              `https://consumer-api.wolt.com/consumer-api/consumer-assortment/v1/venues/slug/${slug}/assortment/items`,
              {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                body: JSON.stringify({ item_ids: testIds })
              }
            );
            apiStatus = resp.status;
            if(resp.ok) {
              const data = await resp.json();
              apiItems = data.items || [];
              if(apiItems.length > 0) {
                hasIdField   = 'id'           in apiItems[0];
                hasGtinField = 'barcode_gtin' in apiItems[0];
                hasDescField = 'description'  in apiItems[0];
              }
            } else {
              apiError = `HTTP ${resp.status}`;
            }
          } catch(e) { apiError = e.message; }
        }

        // Structural errors
        const structuralErrors = [];
        if(!tokenValid)           structuralErrors.push('Token δεν βρέθηκε ή δεν είναι valid');
        if(!slug)                 structuralErrors.push('Venue slug δεν βρέθηκε από URL');
        if(cards.length === 0)    structuralErrors.push('ItemCard selector δεν επιστρέφει αποτελέσματα — DOM άλλαξε;');
        if(navLinks.length === 0) structuralErrors.push('Navigation links selector δεν επιστρέφει αποτελέσματα — DOM άλλαξε;');
        if(itemIds.length === 0)  structuralErrors.push('Κανένα itemId δεν βρέθηκε από hrefs');
        if(apiStatus && apiStatus !== 200) structuralErrors.push(`Assortment API: ${apiError || 'HTTP ' + apiStatus}`);
        if(apiStatus === 200 && apiItems.length === 0 && testIds.length > 0)
          structuralErrors.push('Assortment API επέστρεψε 0 items για ' + testIds.length + ' IDs');
        if(apiItems.length > 0 && !hasIdField)   structuralErrors.push('Field "id" λείπει από assortment response — schema άλλαξε!');
        if(apiItems.length > 0 && !hasGtinField) structuralErrors.push('Field "barcode_gtin" λείπει από assortment response — schema άλλαξε!');
        if(apiItems.length > 0 && !hasDescField) structuralErrors.push('Field "description" λείπει από assortment response — schema άλλαξε!');

        return {
          timestamp: new Date().toISOString(),
          url: location.href,
          venue_slug: slug,
          duration_ms: Date.now() - startTime,
          dom: {
            item_cards_visible: cards.length,
            nav_links_visible: navLinks.length,
            title_selectors_visible: titles.length,
            item_ids_found: itemIds.length,
            selectors_ok: cards.length > 0 && navLinks.length > 0 && itemIds.length > 0
          },
          token: {
            found: tokenValid,
            expiry_utc: tokenExpiry
          },
          assortment_api: {
            status: apiStatus,
            test_ids_sent: testIds.length,
            items_returned: apiItems.length,
            has_id_field: hasIdField,
            has_barcode_gtin_field: hasGtinField,
            has_description_field: hasDescField,
            error: apiError
          },
          structural_errors: structuralErrors,
          overall_status: structuralErrors.length === 0 ? 'OK' : 'ERROR'
        };
      }
    });

    const report = result.result;
    const ts = formatFilename(new Date());
    const slug = report.venue_slug || 'unknown';
    const filename = `diagnostic_${slug}_${ts}.json`;

    // Αποθήκευση στο chrome.storage
    await chrome.storage.local.set({ efood_last_diagnostic: { report, filename } });

    // Εμφάνιση κουμπιού download
    const dlBtn = document.getElementById('dl-report-btn');
    dlBtn.style.display = 'flex';

    const errCount = report.structural_errors.length;
    if(errCount === 0) {
      status.textContent = `✅ Όλα ΟΚ — ${formatTimestamp(new Date())}`;
    } else {
      status.textContent = `❌ ${errCount} σφάλμα${errCount > 1 ? 'τα' : ''} — κατέβασε report`;
    }

    // Auto-download
    downloadReport(report, filename);

  } catch(e) {
    status.textContent = '❌ Σφάλμα diagnostic: ' + e.message;
  } finally {
    diagBtn.disabled = false;
    diagBtn.textContent = '🔍 Diagnostic';
  }
}

function downloadReport(report, filename) {
  const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

async function downloadLastReport() {
  const data = await chrome.storage.local.get('efood_last_diagnostic');
  if(data.efood_last_diagnostic) {
    const { report, filename } = data.efood_last_diagnostic;
    downloadReport(report, filename);
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const tab = await getCurrentTab();
  const platform = detectPlatform(tab.url || '');
  const badge = document.getElementById('platform-badge');
  const note = document.getElementById('note');
  const btn = document.getElementById('run-btn');
  const stopBtn = document.getElementById('stop-btn');

  const labels = {
    wolt:       '🟢 Wolt Restaurant',
    woltRetail: '🔵 Wolt Retail (QC)',
    box:        '🔵 Box.gr',
    standalone: '🟡 Standalone σελίδα',
    unknown:    '🔴 Μη υποστηριζόμενη σελίδα'
  };
  const notes = {
    wolt:       'Scraping με DOM + click για option groups',
    woltRetail: 'Ανοίγει νέο παράθυρο, zoom 25% — πλήρως αυτόματο',
    box:        'Scraping με DOM + click για option groups',
    standalone: 'AI-based ανάλυση μέσω Edge Function',
    unknown:    'Άνοιξε σελίδα vendor, Wolt ή Box.gr'
  };

  badge.textContent = labels[platform];
  badge.className = `platform-badge ${platform}`;
  note.textContent = notes[platform];

  if (platform !== 'unknown') {
    btn.disabled = false;
    btn.addEventListener('click', runScraper);
  }

  stopBtn.addEventListener('click', stopScraper);

  // Diagnostic buttons
  document.getElementById('diag-btn').addEventListener('click', runDiagnostic);

  const dlReportBtn = document.getElementById('dl-report-btn');
  dlReportBtn.addEventListener('click', downloadLastReport);

  // Εμφάνιση κουμπιού αν υπάρχει αποθηκευμένο report
  const stored = await chrome.storage.local.get('efood_last_diagnostic');
  if(stored.efood_last_diagnostic) {
    dlReportBtn.style.display = 'flex';
  }
});
