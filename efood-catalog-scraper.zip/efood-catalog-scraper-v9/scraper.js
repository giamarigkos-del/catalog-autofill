(function(){
  if(window.__efoodScraping){alert('Τρέχει ήδη...');return;}
  window.__efoodScraping = true;
  window.__efoodStop = false;

  /* ── PLATFORM DETECTION ── */
  const host = location.hostname;
  const path = location.pathname;
  const PLATFORM =
    host.includes('wolt.com') ? (path.includes('/venue/') ? 'woltRetail' : 'wolt') :
    host.includes('box.gr')   ? 'box' :
    'standalone';

  /* ── UTILS ── */
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const stopped = () => window.__efoodStop === true;

  /* ── UI OVERLAY ── */
  const ov = document.createElement('div');
  ov.id = '__efood_ov';
  // Zoom αντιστάθμιση: αν η σελίδα είναι σε 25% zoom, scale(4) κάνει το overlay κανονικό μέγεθος
  const zoomLevel = window.devicePixelRatio || 1;
  const scaleVal = PLATFORM === 'woltRetail' ? 4 : 1;
  ov.style.cssText = `position:fixed;top:16px;right:16px;z-index:999999;background:#0f0f0f;color:#fff;padding:16px 20px;border-radius:12px;font-family:Inter,sans-serif;font-size:14px;min-width:300px;box-shadow:0 4px 24px #0006;transform:scale(${scaleVal});transform-origin:top right;`;
  const platformLabel = {wolt:'Wolt',woltRetail:'Wolt Retail',box:'Box',standalone:'Standalone'}[PLATFORM];
  const platformBadgeColor = PLATFORM === 'box' ? '#F26522' : '#009DE0';
  ov.innerHTML = `
    <div style="font-weight:700;margin-bottom:8px;font-size:15px;">⚡ efood Catalog Scraper <span style="font-size:11px;background:${platformBadgeColor};color:#fff;padding:2px 7px;border-radius:20px;margin-left:4px;">${platformLabel}</span></div>
    <div style="background:#b45309;border-radius:8px;padding:10px 12px;margin-bottom:10px;font-size:12.5px;line-height:1.6;" id="__ef_warn">
      <div style="font-weight:700;margin-bottom:4px;">⚠️ ΣΗΜΑΝΤΙΚΟ — ΜΗΝ:</div>
      <div>• Αλλάξεις tab ή παράθυρο</div>
      <div>• Κάνεις scroll με το ποντίκι</div>
      <div>• Κλικάρεις οπουδήποτε στη σελίδα</div>
      <div style="margin-top:6px;font-weight:600;">Ο scraper ελέγχει τη σελίδα μόνος του!</div>
    </div>
    <div id="__ef_st">Ξεκινάω...</div>
    <div style="margin-top:10px;height:4px;background:#333;border-radius:2px;"><div id="__ef_bar" style="height:4px;background:#f5b800;border-radius:2px;width:0%;transition:width .3s;"></div></div>
    <div style="margin-top:10px;display:flex;gap:8px;">
      <button id="__ef_stop_btn" style="background:#b91c1c;color:#fff;border:none;border-radius:8px;padding:7px 14px;font-weight:700;cursor:pointer;font-size:13px;flex:1;">⏹ Διακοπή (αποθήκευση μερικών)</button>
      <button id="__ef_exit_btn" style="background:#333;color:#fff;border:none;border-radius:8px;padding:7px 14px;font-weight:700;cursor:pointer;font-size:13px;">✕ Έξοδος</button>
    </div>`;
  document.body.appendChild(ov);

  document.getElementById('__ef_stop_btn').addEventListener('click', () => {
    window.__efoodStop = true;
    const btn = document.getElementById('__ef_stop_btn');
    if(btn){ btn.textContent = '⏳ Σταματάω...'; btn.disabled = true; }
  });


  document.getElementById('__ef_exit_btn').addEventListener('click', () => {
    window.__efoodStop = true;
    window.__efoodScraping = false;
    const o = document.getElementById('__efood_ov');
    if(o) o.remove();
  });
  const setSt = (m, p) => {
    const el = document.getElementById('__ef_st');
    if(el) el.textContent = m;
    if(p !== undefined){ const b = document.getElementById('__ef_bar'); if(b) b.style.width = p + '%'; }
  };

  /* ══════════════════════════════════════════
     WOLT RETAIL SCRAPER
     Αρχιτεκτονική (επιβεβαιωμένη με tests):
     - Κατηγορίες: querySelectorAll navigation-bar-link, όλες ορατές χωρίς scroll
     - Ανά κατηγορία: click → await 2500ms → scrollTo(0,0) → await 1000ms
     - Scroll loop: scrollBy(0,900) + await 1200ms
     - Accumulator: Map(href→{name,href}) — virtualization ασφαλής
     - Termination: scrollY === prevScrollY για 3 συνεχόμενα βήματα
  ══════════════════════════════════════════ */
  const woltRetail = {

    /* ── NETWORK CHECK ── */
    async checkNetwork() {
      if(!navigator.onLine) return false;
      try {
        const resp = await fetch('https://dns.google/resolve?name=wolt.com', {
          signal: AbortSignal.timeout(3000),
          cache: 'no-store'
        });
        return resp.ok;
      } catch(e) {
        return false;
      }
    },

    readCards(acc) {
      document.querySelectorAll('[data-test-id="ItemCard"]').forEach(card => {
        const titleEl = card.querySelector('[data-test-id="ImageCentricProductCard.Title"]');
        const name = titleEl ? titleEl.textContent.trim() : '';
        if(!name) return;
        const link = card.closest('a') || card.querySelector('a');
        const href = link ? link.getAttribute('href') : null;
        const key = href || name;
        if(acc.has(key)) return;
        // Τιμή
        let price = null;
        const priceEl = card.querySelector('[data-test-id="ImageCentricProductCardPrice"] span');
        if(priceEl) {
          const pm = priceEl.textContent.replace(',','.').match(/[\d]+\.?[\d]*/);
          if(pm) price = parseFloat(pm[0]);
        }
        const itemId = href ? (href.match(/itemid-([a-f0-9]+)/)?.[1] || null) : null;
        acc.set(key, { name, href, price, itemId });
      });
    },

    // DOM stability check: περιμένει ο αριθμός ItemCards να σταθεροποιηθεί
    // Αντικαθιστά το fixed sleep(1200ms) — προχωράει μόλις τα items φορτώσουν
    // Αν δεν σταθεροποιηθεί μέσα σε maxWait → network check
    async waitForDomStable(catIndex, catResults) {
      const pollInterval = 200;   // έλεγχος κάθε 200ms
      const stableNeeded = 2;     // χρειάζονται 2 συνεχόμενα ίδια counts
      const maxWait = 8000;       // max αναμονή πριν network check
      let stableCount = 0;
      let prevCount = -1;
      let elapsed = 0;

      while(elapsed < maxWait) {
        if(stopped()) return 'stopped';
        const count = document.querySelectorAll('[data-test-id="ItemCard"]').length;
        if(count === prevCount) {
          stableCount++;
          if(stableCount >= stableNeeded) return 'ok'; // stable!
        } else {
          stableCount = 0;
          prevCount = count;
        }
        await sleep(pollInterval);
        elapsed += pollInterval;
      }

      // Δεν σταθεροποιήθηκε μέσα σε 8s → network check
      setSt('⏳ Αργή φόρτωση — έλεγχος δικτύου...', undefined);
      const online = await this.checkNetwork();
      if(!online) return await this.pauseScraping(catIndex, catResults);
      return await this.slowNetworkChoice(catIndex, catResults);
    },

    async scrapeCategory(catName, link, acc, catIndex, catResults) {
      const prevSize = acc.size;

      // Πλοήγηση στην κατηγορία — fixed wait για initial render
      link.click();
      await sleep(2500);
      if(stopped()) return;

      window.scrollTo(0, 0);
      await sleep(500);
      if(stopped()) return;

      // Scroll loop με scrollY-based termination
      let prevScrollY = -1;
      let stagnant = 0;

      while(true) {
        if(stopped()) break;

        // Διαβάζουμε ΠΡΙΝ το scroll
        this.readCards(acc);

        window.scrollBy(0, 900);

        // DOM stability: περιμένει τα items να φορτώσουν αντί για fixed sleep
        // Αν ήδη είναι stable (γρήγορο δίκτυο ή λίγα items) → περνάει αμέσως
        const stableResult = await this.waitForDomStable(catIndex, catResults);
        if(stableResult === 'stopped') break;

        // Jitter για anti-detection
        await sleep(200 + Math.floor(Math.random() * 300));
        if(stopped()) break;

        // Διαβάζουμε ΜΕΤΑ (double-read για ασφάλεια)
        this.readCards(acc);

        const newY = window.scrollY;
        if(newY === prevScrollY) {
          stagnant++;
          if(stagnant >= 3) break; // τέλος σελίδας
        } else {
          stagnant = 0;
        }
        prevScrollY = newY;
      }

      const gained = acc.size - prevSize;
      return gained;
    },

    async run() {
      setSt('Βρίσκω κατηγορίες...', 2);
      await sleep(1500); // σταθεροποίηση σελίδας

      // Συλλογή navigation links
      const allLinks = Array.from(document.querySelectorAll('[data-test-id="navigation-bar-link"]'))
        .filter(a => (a.getAttribute('href') || '').includes('/items/'));

      if(!allLinks.length) {
        setSt('❌ Δεν βρέθηκαν κατηγορίες. Σιγουρέψου ότι είσαι σε Wolt Retail σελίδα.', 0);
        window.__efoodScraping = false;
        return { catalog: [], source: 'woltRetail' };
      }

      setSt(`Βρέθηκαν ${allLinks.length} κατηγορίες`, 5);
      await sleep(500);

      // Accumulator: href → {name, price}
      // Ξεχωριστό Map ανά κατηγορία για να χτίσουμε το catalog σωστά
      const catResults = []; // [{name, items:[...]}]

      for(let i = 0; i < allLinks.length; i++) {
        if(stopped()) break;

        const link = allLinks[i];
        const catName = link.textContent.trim() || `Κατηγορία ${i+1}`;
        const pct = Math.round(5 + (i / allLinks.length) * 90);

        setSt(`[${i+1}/${allLinks.length}] ${catName}...`, pct);

        const catAcc = new Map();
        await this.scrapeCategory(catName, link, catAcc, i + 1, catResults);

        if(catAcc.size > 0) {
          catResults.push({
            name: catName,
            items: Array.from(catAcc.values()).map(({ name, price, itemId }) => ({
              name,
              price: price !== null ? price : null,
              description: null,
              gtin: null,
              confidence: 'high',
              notes: null,
              option_groups: [],
              _itemId: itemId
            }))
          });
        }

        if(stopped()) {
          setSt(`⏹ Σταματήθηκε μετά από ${i+1}/${allLinks.length} κατηγορίες`, pct);
          break;
        }
      }

      // ── ENRICHMENT + DEBUG LOGGER ──
      const _dbg = [];
      const logDebug = (msg, isWarning=false) => {
        _dbg.push({ t: Date.now(), msg, warn: isWarning });
        // Αν είναι warning → εμφάνισε κουμπί download logs στο overlay
        if(isWarning) {
          let dlBtn = document.getElementById('__ef_dl_logs');
          if(!dlBtn) {
            dlBtn = document.createElement('button');
            dlBtn.id = '__ef_dl_logs';
            dlBtn.textContent = '⬇ Κατέβασε Logs';
            dlBtn.style.cssText = 'background:#b45309;color:#fff;border:none;border-radius:8px;padding:6px 12px;font-weight:700;cursor:pointer;font-size:12px;margin-top:8px;width:100%;';
            dlBtn.onclick = () => downloadLogs();
            const ov = document.getElementById('__efood_ov');
            if(ov) ov.appendChild(dlBtn);
          }
        }
      };
      const downloadLogs = () => {
        const report = { timestamp: new Date().toISOString(), url: location.href, logs: _dbg };
        const blob = new Blob([JSON.stringify(report, null, 2)], {type:'application/json'});
        const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
        a.download = 'efood_scraper_logs.json';
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(a.href), 2000);
      };

      // ── DEDUP — αφαίρεση διπλότυπων πριν το enrichment ──
      // Within-category: ίδιο name+price στην ίδια κατηγορία → κράτα μόνο το πρώτο (scraping error)
      // Cross-category: ίδιο name+price σε διαφορετικές κατηγορίες → flag _duplicate:true στις επόμενες
      {
        const globalSeen = new Map(); // key → πρώτη κατηγορία
        let withinRemoved = 0, crossFlagged = 0;

        catResults.forEach(cat => {
          const withinSeen = new Set();
          const kept = [];
          cat.items.forEach(item => {
            const key = (item.name || '') + '||' + (item.price ?? '');
            // Within-category dedup
            if(withinSeen.has(key)) { withinRemoved++; return; }
            withinSeen.add(key);
            // Cross-category dedup
            if(globalSeen.has(key)) {
              item._duplicate = true; // flag — η πρώτη εμφάνιση είναι master
              crossFlagged++;
            } else {
              globalSeen.set(key, cat.name);
            }
            kept.push(item);
          });
          cat.items = kept;
        });

        logDebug(`dedup: ${withinRemoved} within-category removed, ${crossFlagged} cross-category flagged`);
      }

      // ── ENRICHMENT — assortment API (1 call για όλα τα items) ──
      logDebug(`url: ${location.href.slice(0,80)}`);

      const allItemsFlat = [];
      catResults.forEach(cat => cat.items.forEach(item => { if(item._itemId) allItemsFlat.push(item); }));
      logDebug(`items with itemId: ${allItemsFlat.length}`);

      // Venue slug από URL (/venue/{slug})
      const slug = location.pathname.match(/\/venue\/([^/?#]+)/)?.[1] || null;
      logDebug(`slug: ${slug}`);

      // Token από __wtoken cookie
      let token = null;
      try {
        const raw = document.cookie.split(';').map(c=>c.trim()).find(c=>c.startsWith('__wtoken='))?.split('=')?.[1];
        if(raw) token = JSON.parse(decodeURIComponent(raw)).accessToken || null;
      } catch(e) { logDebug(`token parse error: ${e.message}`, true); }
      logDebug(`token found: ${!!token}`);

      if(slug && token && allItemsFlat.length > 0 && !stopped()) {
        const total = allItemsFlat.length;
        const itemIds = allItemsFlat.map(item => item._itemId);
        logDebug(`enrichment start: ${total} items via assortment API (direct fetch)`);
        setSt(`Εμπλουτισμός ${total} items (1 call)...`, 92);

        try {
          const resp = await fetch(
            `https://consumer-api.wolt.com/consumer-api/consumer-assortment/v1/venues/slug/${slug}/assortment/items`,
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
              },
              body: JSON.stringify({ item_ids: itemIds })
            }
          );

          logDebug(`assortment API status: ${resp.status}`);

          if(resp.ok) {
            const data = await resp.json();
            const items = data.items || [];
            logDebug(`assortment returned ${items.length} items`);

            // Map: itemId → {gtin, description, vat}
            const enrichMap = {};
            items.forEach(it => {
              enrichMap[it.id] = {
                gtin: it.barcode_gtin || null,
                description: it.description || null,
                vat: it.vat_percentage ?? null
              };
            });

            let gtinFound = 0, descFound = 0;
            allItemsFlat.forEach(item => {
              const d = enrichMap[item._itemId];
              if(d) {
                if(d.gtin)        { item.gtin = d.gtin; gtinFound++; }
                if(d.description) { item.description = d.description; descFound++; }
                if(d.vat !== null) item._vat = d.vat;
              }
            });
            logDebug(`enrichment done: gtinFound=${gtinFound} descFound=${descFound} / ${total}`);
            setSt(`Εμπλουτισμός ✓ ${gtinFound}/${total} GTINs · ${descFound}/${total} περιγραφές`, 99);

            // ── AUTO HEALTH CHECK (structural only — δεν χτυπάει για null fields) ──
            const hc = {
              timestamp: formatTimestamp(new Date()),
              venue_slug: slug,
              url: location.href,
              assortment_api: {
                status: 200,
                items_requested: total,
                items_returned: items.length,
                has_id_field:          items.length > 0 && items[0].id !== undefined,
                has_barcode_gtin_field: items.length > 0 && 'barcode_gtin' in items[0],
                has_description_field:  items.length > 0 && 'description' in items[0],
                gtin_coverage_pct:     total > 0 ? Math.round(gtinFound/total*100) : 0,
                desc_coverage_pct:     total > 0 ? Math.round(descFound/total*100) : 0
              },
              structural_errors: []
            };
            if(items.length === 0 && total > 0)
              hc.structural_errors.push('API επέστρεψε 0 items για ' + total + ' IDs');
            if(items.length > 0 && !hc.assortment_api.has_id_field)
              hc.structural_errors.push('Το field "id" λείπει από το response — schema άλλαξε!');
            if(items.length > 0 && !hc.assortment_api.has_barcode_gtin_field)
              hc.structural_errors.push('Το field "barcode_gtin" λείπει από το response — schema άλλαξε!');
            if(items.length > 0 && !hc.assortment_api.has_description_field)
              hc.structural_errors.push('Το field "description" λείπει από το response — schema άλλαξε!');

            if(hc.structural_errors.length > 0) {
              hc.structural_errors.forEach(e => logDebug('HEALTH CHECK ERROR: ' + e, true));
            }
            // Αποθήκευση στο chrome.storage για download από popup
            try {
              chrome.storage.local.set({ 'efood_last_health_check': hc });
            } catch(e) { /* silent */ }
            logDebug(`health check: ${hc.structural_errors.length === 0 ? 'OK' : hc.structural_errors.length + ' errors'}`);
          } else {
            logDebug(`enrichment failed: HTTP ${resp.status}`, true);
            setSt(`⚠ Enrichment απέτυχε (HTTP ${resp.status})`, 92);
          }
        } catch(e) {
          logDebug(`enrichment exception: ${e.message}`, true);
          setSt(`⚠ Enrichment exception: ${e.message}`, 92);
        }
      } else {
        if(!slug)  logDebug('slug NOT FOUND — enrichment skipped', true);
        if(!token) logDebug('token NOT FOUND — enrichment skipped', true);
      }

      // Αφαίρεση _itemId
      catResults.forEach(cat => cat.items.forEach(item => delete item._itemId));

      return { catalog: catResults, source: 'woltRetail', _debug: _dbg.map(d => d.msg) };
    }
  };

  /* ══════════════════════════════════════════
     WOLT RESTAURANTS SCRAPER — API-based (v7.1)
     Endpoint: GET consumer-api.wolt.com/consumer-api/consumer-assortment/v1/venues/slug/{slug}/assortment
     Επιστρέφει: categories[] + items[] + options[] — όλα σε 1 call, μηδέν DOM
     Fixes v7.1:
     - Conditional option groups (prerequisite_values): φέρνονται κανονικά, σημειώνονται ως _conditional:true
     - Τιμές: fallback chain item.price → item.original_price → item.lowest_price → null
  ══════════════════════════════════════════ */
  const wolt = {

    async run() {
      const slug = location.pathname.match(/\/restaurant\/([^/?#]+)/)?.[1] || null;

      if(!slug) {
        setSt('❌ Δεν βρέθηκε slug εστιατορίου στο URL.', 0);
        window.__efoodScraping = false;
        return { catalog: [], source: 'wolt' };
      }

      setSt(`🍔 Wolt API: Φορτώνω κατάλογο "${slug}"...`, 10);

      let data;
      try {
        const resp = await fetch(
          `https://consumer-api.wolt.com/consumer-api/consumer-assortment/v1/venues/slug/${slug}/assortment`,
          { credentials: 'include', cache: 'no-store' }
        );
        if(!resp.ok) throw new Error(`HTTP ${resp.status}`);
        data = await resp.json();
      } catch(e) {
        setSt(`❌ Wolt API σφάλμα: ${e.message}`, 0);
        window.__efoodScraping = false;
        return { catalog: [], source: 'wolt' };
      }

      const categories = data.categories || [];
      const items      = data.items      || [];
      const options    = data.options    || [];

      if(items.length === 0) {
        setSt('❌ Wolt API: 0 προϊόντα στο response.', 0);
        window.__efoodScraping = false;
        return { catalog: [], source: 'wolt' };
      }

      setSt(`✓ ${items.length} προϊόντα — Χτίζω κατάλογο...`, 70);

      // Index: option_id → option object
      const optMap = {};
      options.forEach(o => { optMap[o.id] = o; });

      // Index: item_id → item object
      const itemMap = {};
      items.forEach(i => { itemMap[i.id] = i; });

      const catalog = [];
      categories.forEach(cat => {
        const catItems = [];
        (cat.item_ids || []).forEach(itemId => {
          const item = itemMap[itemId];
          if(!item) return;
          const name = item.name?.trim() || '';
          if(!name) return;

          // ── Τιμή: fallback chain ──
          // item.price είναι null σε items χωρίς fixed price (π.χ. sold by weight)
          // item.original_price → τιμή πριν discount
          // item.lowest_price → χαμηλότερη τιμή 30 ημερών
          const rawPrice = item.price ?? item.original_price ?? item.lowest_price ?? null;
          const price = rawPrice != null ? rawPrice / 100 : null;

          // ── Option groups: ΟΛΑ τα groups, συμπεριλαμβανομένων conditional ──
          // Τα conditional groups έχουν prerequisite_values non-empty
          // Τα φέρνουμε κανονικά και τα σημειώνουμε με _conditional:true
          const option_groups = (item.options || []).map(o => {
            const g = optMap[o.option_id];
            if(!g) return null;
            const min = o.multi_choice_config?.total_range?.min ?? 0;
            const isConditional = Array.isArray(o.prerequisite_values) && o.prerequisite_values.length > 0;
            const group = {
              title: o.name?.trim() || g.name?.trim() || '',
              type: min >= 1 ? 'required_single' : 'optional_multi',
              options: (g.values || []).map(v => ({
                name: v.name?.trim() || '',
                price_delta: v.price ? v.price / 100 : 0
              })).filter(v => v.name)
            };
            if(isConditional) group._conditional = true;
            return group;
          }).filter(Boolean);

          catItems.push({
            name,
            price,
            description: item.description?.trim() || null,
            confidence: 'high',
            notes: null,
            option_groups
          });
        });

        if(catItems.length > 0) {
          catalog.push({ name: cat.name?.trim() || 'Γενικά', items: catItems });
        }
      });

      const totalItems = catalog.reduce((s, c) => s + c.items.length, 0);
      const withDesc   = catalog.reduce((s, c) => s + c.items.filter(i => i.description).length, 0);
      const withOpts   = catalog.reduce((s, c) => s + c.items.filter(i => i.option_groups.length > 0).length, 0);
      const withPrice  = catalog.reduce((s, c) => s + c.items.filter(i => i.price !== null).length, 0);
      const descPct    = totalItems > 0 ? Math.round(withDesc  / totalItems * 100) : 0;
      const pricePct   = totalItems > 0 ? Math.round(withPrice / totalItems * 100) : 0;

      setSt(`✅ ${catalog.length} κατηγορίες · ${totalItems} προϊόντα · ${withOpts} με options · ${descPct}% περιγραφές · ${pricePct}% τιμές`, 99);

      return { catalog, source: 'wolt' };
    }
  };

  /* ══════════════════════════════════════════
     BOX SCRAPER — API-based (v7)
     Αρχιτεκτονική (επιβεβαιωμένη 28/6/2026):
     URL format: box.gr/delivery/{area}/{slug} — ΔΕΝ περιέχει collectionType
     Βήμα 1: GET /api/shops/findShopByVanityUrl?vanity_url={slug}&origin=shop
             → payload.shop.collectionType (numeric)
     Βήμα 2: GET /api/shops/getItems?categories=true&products=true&offers=true&tags=true&collectionType={id}
             → payload.products[] + payload.categories[]
     Auth: credentials:'include' (χρησιμοποιεί Box:token από cookies)
  ══════════════════════════════════════════ */
  const box = {

    async run() {
      // ── Εξαγωγή slug από URL ──
      // Format: box.gr/delivery/{area}/{slug}
      const slugMatch = location.pathname.match(/\/delivery\/[^/]+\/([^/?#]+)/);
      const slug = slugMatch?.[1] || null;

      if(!slug) {
        setSt('❌ Δεν βρέθηκε slug στο URL. Βεβαιώσου ότι είσαι σε σελίδα box.gr/delivery/...', 0);
        window.__efoodScraping = false;
        return { catalog: [], source: 'box' };
      }

      // ── Βήμα 1: findShopByVanityUrl → collectionType ──
      setSt(`📦 Box: Αναζήτηση καταστήματος "${slug}"...`, 10);
      let collectionType = null;
      try {
        const shopResp = await fetch(
          `https://consumer.box.gr/api/shops/findShopByVanityUrl?vanity_url=${encodeURIComponent(slug)}&origin=shop`,
          { credentials: 'include', cache: 'no-store' }
        );
        if(!shopResp.ok) throw new Error(`HTTP ${shopResp.status}`);
        const shopData = await shopResp.json();
        collectionType = shopData?.payload?.shop?.collectionType ?? null;
        if(!collectionType) throw new Error('collectionType δεν βρέθηκε στο response');
      } catch(e) {
        setSt(`❌ Box: Αποτυχία εύρεσης καταστήματος — ${e.message}`, 0);
        window.__efoodScraping = false;
        return { catalog: [], source: 'box' };
      }

      setSt(`📦 Box API: collectionType=${collectionType} — Φορτώνω κατάλογο...`, 30);

      // ── Βήμα 2: getItems ──
      let data;
      try {
        const url = `https://consumer.box.gr/api/shops/getItems?categories=true&products=true&offers=true&tags=true&collectionType=${collectionType}`;
        const resp = await fetch(url, { credentials: 'include', cache: 'no-store' });
        if(!resp.ok) throw new Error(`HTTP ${resp.status}`);
        data = await resp.json();
      } catch(e) {
        setSt(`❌ Box API σφάλμα: ${e.message}`, 0);
        window.__efoodScraping = false;
        return { catalog: [], source: 'box' };
      }

      const products = data?.payload?.products || [];
      if(products.length === 0) {
        setSt('❌ Box API: 0 προϊόντα. Ο κατάλογος είναι κενός ή το collectionType είναι λάθος.', 0);
        window.__efoodScraping = false;
        return { catalog: [], source: 'box' };
      }

      setSt(`✓ ${products.length} προϊόντα — Ομαδοποίηση...`, 60);

      // ── Ομαδοποίηση per κατηγορία ──
      // Κάθε product έχει nested category object με {_id, name, categoryIndex}
      // Ταξινομούμε κατηγορίες κατά categoryIndex για σωστή σειρά
      const catMap = new Map(); // categoryId → {name, index, items:[]}

      products.forEach(p => {
        if(!p.enabled || !p.available) return; // skip disabled/unavailable

        const cat = p.category || {};
        const catId = cat._id || 'unknown';
        if(!catMap.has(catId)) {
          catMap.set(catId, {
            name: cat.name || 'Γενικά',
            index: cat.categoryIndex ?? 999,
            items: []
          });
        }

        const price = p.finalPrice != null ? p.finalPrice / 100 : null;
        const description = p.info?.el?.trim() || null;
        const name = p.name?.trim() || '';
        if(!name) return;

        // ── Selections → option_groups (v7.2) ──
        // product.selections[] = [{title, necessary, choices:[{title, changeInPrice}]}]
        const option_groups = (p.selections || []).map(sel => {
          const choices = (sel.choices || []).filter(c => c.available !== false);
          if(!choices.length) return null;
          return {
            title: sel.title?.trim() || '',
            type: sel.necessary ? 'required_single' : 'optional_multi',
            options: choices.map(c => ({
              name: c.title?.trim() || '',
              price_delta: c.changeInPrice ?? 0
            })).filter(o => o.name)
          };
        }).filter(Boolean);

        catMap.get(catId).items.push({
          name,
          price,
          description,
          confidence: 'high',
          notes: null,
          option_groups
        });
      });

      // Ταξινόμηση κατηγοριών κατά categoryIndex
      const catalog = [...catMap.values()]
        .sort((a, b) => a.index - b.index)
        .filter(c => c.items.length > 0)
        .map(c => ({ name: c.name, items: c.items }));

      // ── Dedup (ίδιο name+price εντός κατηγορίας) ──
      catalog.forEach(cat => {
        const seen = new Set();
        cat.items = cat.items.filter(item => {
          const key = item.name + '||' + item.price;
          if(seen.has(key)) return false;
          seen.add(key);
          return true;
        });
      });

      const totalItems = catalog.reduce((s, c) => s + c.items.length, 0);
      const withDesc   = catalog.reduce((s, c) => s + c.items.filter(i => i.description).length, 0);
      const descPct    = totalItems > 0 ? Math.round(withDesc / totalItems * 100) : 0;

      setSt(`✅ ${catalog.length} κατηγορίες · ${totalItems} προϊόντα · ${descPct}% περιγραφές`, 99);

      return { catalog, source: 'box' };
    }
  };

  /* ══════════════════════════════════════════
     STANDALONE SCRAPER (αναλλοίωτος)
  ══════════════════════════════════════════ */
  /* dom-to-semantic-markdown v1.5.0 — inline browser bundle */
  const htmlToSMD = (() => {
    const exports = {};
    'use strict';

    // this is by value copy of the global Node
    const _Node = {
        /** node is an element. */
        ELEMENT_NODE: 1,
        /** node is a Text node. */
        TEXT_NODE: 3};

    function htmlToMarkdownAST(element, options, indentLevel = 0) {
        let result = [];
        const debugLog = (message) => {
            if (options?.debug) {
                console.log(message);
            }
        };
        element.childNodes.forEach((childElement) => {
            const overriddenElementProcessing = options?.overrideElementProcessing?.(childElement, options, indentLevel);
            if (overriddenElementProcessing) {
                debugLog(`Element Processing Overridden: '${childElement.nodeType}'`);
                result.push(...overriddenElementProcessing);
            }
            else if (childElement.nodeType === _Node.TEXT_NODE) {
                const textContent = escapeMarkdownCharacters(childElement.textContent?.trim() ?? '');
                if (textContent && !!childElement.textContent) {
                    debugLog(`Text Node: '${textContent}'`);
                    // preserve whitespaces when text childElement is not empty
                    result.push({ type: 'text', content: childElement.textContent?.trim() });
                }
            }
            else if (childElement.nodeType === _Node.ELEMENT_NODE) {
                const elem = childElement;
                if (/^h[1-6]$/i.test(elem.tagName)) {
                    const level = parseInt(elem.tagName.substring(1));
                    debugLog(`Heading ${level}`);
                    result.push({
                        type: 'heading',
                        level,
                        content: htmlToMarkdownAST(elem, options) // Process child elements
                    });
                }
                else if (elem.tagName.toLowerCase() === 'p') {
                    debugLog("Paragraph");
                    result.push(...htmlToMarkdownAST(elem, options));
                    // Add a new line after the paragraph
                    result.push({ type: 'text', content: '\n\n' });
                }
                else if (elem.tagName.toLowerCase() === 'a') {
                    debugLog(`Link: '${elem.href}' with text '${elem.textContent}'`);
                    // Check if the href is a data URL for an image
                    if (typeof elem.href === 'string' && elem.href.startsWith("data:image")) {
                        // If it's a data URL for an image, skip this link
                        result.push({
                            type: 'link',
                            href: '-',
                            content: htmlToMarkdownAST(elem, options)
                        });
                    }
                    else {
                        // Process the link as usual
                        let href = elem.href;
                        if (typeof href === 'string') {
                            href = options?.websiteDomain && href.startsWith(options.websiteDomain) ?
                                href.substring(options.websiteDomain.length) : href;
                        }
                        else {
                            href = '#'; // Use a default value when href is not a string
                        }
                        // if all children are text,
                        if (Array.from(elem.childNodes).every(_ => _.nodeType === _Node.TEXT_NODE)) {
                            result.push({
                                type: 'link',
                                href: href,
                                content: [{ type: 'text', content: elem.textContent?.trim() ?? '' }]
                            });
                        }
                        else {
                            result.push({
                                type: 'link',
                                href: href,
                                content: htmlToMarkdownAST(elem, options)
                            });
                        }
                    }
                }
                else if (elem.tagName.toLowerCase() === 'img') {
                    debugLog(`Image: src='${elem.src}', alt='${elem.alt}'`);
                    if (elem.src?.startsWith("data:image")) {
                        result.push({
                            type: 'image',
                            src: '-',
                            alt: escapeMarkdownCharacters(elem.alt)
                        });
                    }
                    else {
                        const src = options?.websiteDomain && elem.src?.startsWith(options.websiteDomain) ?
                            elem.src?.substring(options.websiteDomain.length) :
                            elem.src;
                        result.push({ type: 'image', src, alt: escapeMarkdownCharacters(elem.alt) });
                    }
                }
                else if (elem.tagName.toLowerCase() === 'video') {
                    debugLog(`Video: src='${elem.src}', poster='${elem.poster}', controls='${elem.controls}'`);
                    result.push({
                        type: 'video',
                        src: elem.src,
                        poster: escapeMarkdownCharacters(elem.poster),
                        controls: elem.controls
                    });
                }
                else if (elem.tagName.toLowerCase() === 'ul' || elem.tagName.toLowerCase() === 'ol') {
                    debugLog(`${elem.tagName.toLowerCase() === 'ul' ? 'Unordered' : 'Ordered'} List`);
                    result.push({
                        type: 'list',
                        ordered: elem.tagName.toLowerCase() === 'ol',
                        items: Array.from(elem.children).map(li => ({
                            type: 'listItem',
                            content: htmlToMarkdownAST(li, options, indentLevel + 1)
                        }))
                    });
                }
                else if (elem.tagName.toLowerCase() === 'br') {
                    debugLog("Line Break");
                    result.push({ type: 'text', content: '\n' });
                }
                else if (elem.tagName.toLowerCase() === 'table') {
                    debugLog("Table");
                    let colIds = [];
                    if (options?.enableTableColumnTracking) {
                        // Generate unique column IDs
                        const headerCells = Array.from(elem.querySelectorAll('th, td'));
                        headerCells.forEach((_, index) => {
                            colIds.push(`col-${index}`);
                        });
                    }
                    const tableRows = Array.from(elem.querySelectorAll('tr'));
                    const markdownTableRows = tableRows.map(row => {
                        let columnIndex = 0;
                        const cells = Array.from(row.querySelectorAll('th, td')).map((cell) => {
                            const colspan = parseInt(cell.getAttribute('colspan') || '1', 10);
                            const rowspan = parseInt(cell.getAttribute('rowspan') || '1', 10);
                            const cellNode = {
                                type: 'tableCell',
                                content: cell.nodeType === _Node.TEXT_NODE
                                    ? escapeMarkdownCharacters(cell.textContent?.trim() ?? '')
                                    : htmlToMarkdownAST(cell, options, indentLevel + 1),
                                colId: colIds[columnIndex],
                                colspan: colspan > 1 ? colspan : undefined,
                                rowspan: rowspan > 1 ? rowspan : undefined
                            };
                            columnIndex += colspan;
                            return cellNode;
                        });
                        return { type: 'tableRow', cells };
                    });
                    if (markdownTableRows.length > 0) {
                        // Check if the first row contains header cells
                        const hasHeaders = tableRows[0].querySelector('th') !== null;
                        if (hasHeaders) {
                            // Create a header separator row
                            const headerSeparatorCells = Array.from(tableRows[0].querySelectorAll('th, td'))
                                .map(() => ({
                                type: 'tableCell',
                                content: '---',
                                colId: undefined,
                                colspan: undefined,
                                rowspan: undefined,
                            }));
                            const headerSeparatorRow = {
                                type: 'tableRow',
                                cells: headerSeparatorCells,
                            };
                            markdownTableRows.splice(1, 0, headerSeparatorRow);
                        }
                    }
                    result.push({ type: 'table', rows: markdownTableRows, colIds });
                }
                else if (elem.tagName.toLowerCase() === 'head' && !!options?.includeMetaData) {
                    const node = {
                        type: 'meta',
                        content: {
                            standard: {},
                            openGraph: {},
                            twitter: {},
                        }
                    };
                    elem.querySelectorAll('title')
                        .forEach(titleElem => {
                        node.content.standard['title'] = escapeMarkdownCharacters(titleElem.text);
                    });
                    // Extract meta tags
                    const metaTags = elem.querySelectorAll('meta');
                    const nonSemanticTagNames = [
                        "viewport",
                        "referrer",
                        "Content-Security-Policy"
                    ];
                    metaTags.forEach(metaTag => {
                        const name = metaTag.getAttribute('name');
                        const property = metaTag.getAttribute('property');
                        const content = metaTag.getAttribute('content');
                        if (property && property.startsWith('og:') && content) {
                            if (options.includeMetaData === 'extended') {
                                node.content.openGraph[property.substring(3)] = content;
                            }
                        }
                        else if (name && name.startsWith('twitter:') && content) {
                            if (options.includeMetaData === 'extended') {
                                node.content.twitter[name.substring(8)] = content;
                            }
                        }
                        else if (name && !nonSemanticTagNames.includes(name) && content) {
                            node.content.standard[name] = content;
                        }
                    });
                    // Extract JSON-LD data
                    if (options.includeMetaData === 'extended') {
                        const jsonLdData = [];
                        const jsonLDScripts = elem.querySelectorAll('script[type="application/ld+json"]');
                        jsonLDScripts.forEach(script => {
                            try {
                                const jsonContent = script.textContent;
                                if (jsonContent) {
                                    const parsedData = JSON.parse(jsonContent);
                                    jsonLdData.push(parsedData);
                                }
                            }
                            catch (error) {
                                console.error('Failed to parse JSON-LD', error);
                            }
                        });
                        node.content.jsonLd = jsonLdData;
                    }
                    result.push(node);
                }
                else {
                    const content = escapeMarkdownCharacters(elem.textContent || '');
                    switch (elem.tagName.toLowerCase()) {
                        case 'noscript':
                        case 'script':
                        case 'style':
                        case 'html':
                            // blackhole..
                            break;
                        case 'strong':
                        case 'b':
                            if (content) {
                                debugLog(`Bold: '${content}'`);
                                result.push({
                                    type: 'bold',
                                    content: htmlToMarkdownAST(elem, options, indentLevel + 1)
                                });
                            }
                            break;
                        case 'em':
                        case 'i':
                            if (content) {
                                debugLog(`Italic: '${content}'`);
                                result.push({
                                    type: 'italic',
                                    content: htmlToMarkdownAST(elem, options, indentLevel + 1)
                                });
                            }
                            break;
                        case 's':
                        case 'strike':
                            if (content) {
                                debugLog(`Strikethrough: '${content}'`);
                                result.push({
                                    type: 'strikethrough',
                                    content: htmlToMarkdownAST(elem, options, indentLevel + 1)
                                });
                            }
                            break;
                        case 'code':
                            if (content) {
                                // Handling inline code differently
                                const isCodeBlock = elem.parentNode && elem.parentNode.nodeName.toLowerCase() === 'pre';
                                debugLog(`${isCodeBlock ? 'Code Block' : 'Inline Code'}: '${content}'`);
                                const languageClass = elem.className?.split(" ").find(cls => cls.startsWith("language-"));
                                const language = languageClass ? languageClass.replace("language-", "") : "";
                                result.push({
                                    type: 'code',
                                    content: elem.textContent?.trim() ?? '',
                                    language,
                                    inline: !isCodeBlock
                                });
                            }
                            break;
                        case 'blockquote':
                            debugLog(`Blockquote`);
                            result.push({
                                type: 'blockquote',
                                content: htmlToMarkdownAST(elem, options)
                            });
                            break;
                        case 'article':
                        case 'aside':
                        case 'details':
                        case 'figcaption':
                        case 'figure':
                        case 'footer':
                        case 'header':
                        case 'main':
                        case 'mark':
                        case 'nav':
                        case 'section':
                        case 'summary':
                        case 'time':
                            debugLog(`Semantic HTML Element: '${elem.tagName}'`);
                            result.push({
                                type: 'semanticHtml',
                                htmlType: elem.tagName.toLowerCase(),
                                content: htmlToMarkdownAST(elem, options)
                            });
                            break;
                        default:
                            const unhandledElementProcessing = options?.processUnhandledElement?.(elem, options, indentLevel);
                            if (unhandledElementProcessing) {
                                debugLog(`Processing Unhandled Element: '${elem.tagName}'`);
                                result.push(...unhandledElementProcessing);
                            }
                            else {
                                debugLog(`Generic HTMLElement: '${elem.tagName}'`);
                                result.push(...htmlToMarkdownAST(elem, options, indentLevel + 1));
                            }
                            break;
                    }
                }
            }
        });
        return result;
    }
    function escapeMarkdownCharacters(text, isInlineCode = false) {
        if (isInlineCode || !text?.trim()) {
            // In inline code, we don't escape any characters
            return text;
        }
        // First, replace special HTML characters with their entity equivalents
        let escapedText = text.replace(/&/g, '&amp;') // Replace & first
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        // Then escape characters that have special meaning in Markdown
        escapedText = escapedText.replace(/([\\`*_{}[\]#+!|])/g, '\\$1');
        return escapedText;
    }

    function aggressiveTrim(str) {
        if (typeof str !== 'string')
            return '';
        return str.replace(/^[\s\u00A0\u200B]+|[\s\u00A0\u200B]+$/g, '');
    }
    // --- Metadata Rendering ---
    function renderSimpleMetaObject(obj, indent = '') {
        if (!obj || Object.keys(obj).length === 0)
            return '';
        let metaString = '';
        Object.keys(obj).forEach(key => {
            const value = String(obj[key] ?? '');
            metaString += `${indent}${key}: "${value.replace(/"/g, '\\"')}"\n`;
        });
        return metaString;
    }
    function markdownMetaASTToString(nodes, options) {
        if (!options?.includeMetaData) {
            return '';
        }
        const metaNode = findInMarkdownAST(nodes, _ => _.type === 'meta');
        if (!metaNode) {
            return '---\n---\n\n';
        }
        let markdownString = '---\n';
        if (metaNode.content.standard) {
            markdownString += renderSimpleMetaObject(metaNode.content.standard);
        }
        if (options.includeMetaData === 'extended') {
            if (metaNode.content.openGraph && Object.keys(metaNode.content.openGraph).length > 0) {
                markdownString += 'openGraph:\n';
                markdownString += renderSimpleMetaObject(metaNode.content.openGraph, '  ');
            }
            if (metaNode.content.twitter && Object.keys(metaNode.content.twitter).length > 0) {
                markdownString += 'twitter:\n';
                markdownString += renderSimpleMetaObject(metaNode.content.twitter, '  ');
            }
            if (metaNode.content.jsonLd && metaNode.content.jsonLd.length > 0) {
                markdownString += 'schema:\n';
                metaNode.content.jsonLd.forEach(item => {
                    if (!item)
                        return;
                    const { '@context': _jldContext, '@type': jldType, ...semanticData } = item;
                    markdownString += `  ${jldType ?? '(unknown type)'}:\n`;
                    Object.keys(semanticData).forEach(key => {
                        const value = semanticData[key];
                        markdownString += `    ${key}: ${JSON.stringify(value ?? null)}\n`;
                    });
                });
            }
        }
        markdownString += '---\n\n\n';
        return markdownString;
    }
    function processNodeContent(content, renderChildren, options, indentLevel) {
        if (typeof content === 'string') {
            return content;
        }
        if (Array.isArray(content)) {
            return renderChildren(content, options, indentLevel);
        }
        return '';
    }
    const nodeRenderers = {
        text: (node) => {
            return typeof node.content === 'string' ? node.content : '';
        },
        bold: (node, options, renderChildren, indentLevel) => {
            const contentString = processNodeContent(node.content, renderChildren, options, indentLevel);
            return `**${aggressiveTrim(contentString)}**`;
        },
        italic: (node, options, renderChildren, indentLevel) => {
            const contentString = processNodeContent(node.content, renderChildren, options, indentLevel);
            return `*${aggressiveTrim(contentString)}*`;
        },
        strikethrough: (node, options, renderChildren, indentLevel) => {
            const contentString = processNodeContent(node.content, renderChildren, options, indentLevel);
            return `~~${aggressiveTrim(contentString)}~~`;
        },
        link: (node, options, renderChildren, indentLevel) => {
            const linkNode = node;
            const contentString = processNodeContent(linkNode.content, renderChildren, options, indentLevel);
            const trimmedLinkContent = aggressiveTrim(contentString);
            const href = linkNode.href ? encodeURI(linkNode.href) : '';
            // Heuristic for using []() vs <a>: if content was simple text that got trimmed, or is just plain text.
            if (trimmedLinkContent &&
                ((Array.isArray(linkNode.content) && linkNode.content.length === 1 && linkNode.content[0].type === 'text' && linkNode.content[0].content === trimmedLinkContent) ||
                    (typeof linkNode.content === 'string' && linkNode.content === trimmedLinkContent) ||
                    (!Array.isArray(linkNode.content) && !trimmedLinkContent.includes('<') && !trimmedLinkContent.includes('\n')))) {
                return `[${trimmedLinkContent}](${href})`;
            }
            return `<a href="${href}">${trimmedLinkContent}</a>`;
        },
        heading: (node, options, renderChildren, indentLevel) => {
            const headingNode = node;
            const contentString = processNodeContent(headingNode.content, renderChildren, options, indentLevel);
            return `${'#'.repeat(headingNode.level)} ${contentString.trim()}\n\n`;
        },
        image: (node) => {
            const imageNode = node;
            const altText = aggressiveTrim(imageNode.alt);
            const srcText = imageNode.src ? encodeURI(imageNode.src) : '';
            return `![${altText}](${srcText})\n`;
        },
        list: (node, options, renderChildren, indentLevel) => {
            const listNode = node;
            let listString = '';
            const itemIndent = ' '.repeat(indentLevel * 2);
            (listNode.items || []).forEach((item, i) => {
                if (!item || !item.content)
                    return;
                const listItemPrefix = listNode.ordered ? `${i + 1}.` : '-';
                const itemContentString = renderChildren(item.content, options, indentLevel + 1).trim();
                listString += `${itemIndent}${listItemPrefix} ${itemContentString}\n`;
            });
            return listString;
        },
        video: (node) => {
            const videoNode = node;
            let videoString = '';
            const videoSrc = videoNode.src ? encodeURI(videoNode.src) : '';
            videoString += `\n![Video](${videoSrc})\n`;
            if (videoNode.poster) {
                const posterSrc = typeof videoNode.poster === 'string' ? encodeURI(videoNode.poster) : '';
                videoString += `![Poster](${posterSrc})\n`;
            }
            if (videoNode.controls !== undefined) {
                videoString += `Controls: ${videoNode.controls}\n`;
            }
            return videoString;
        },
        table: (node, options, renderChildren, indentLevel) => {
            const tableNode = node;
            const rows = tableNode.rows || [];
            if (rows.length === 0)
                return '';
            const maxColumns = Math.max(0, ...rows.map(row => (row.cells || []).reduce((sum, cell) => sum + Math.max(1, cell?.colspan || 1), 0)));
            if (maxColumns === 0)
                return '';
            let tableString = '';
            rows.forEach((row, rowIndex) => {
                if (!row || !row.cells)
                    return;
                let currentColumn = 0;
                let rowString = '';
                row.cells.forEach((cell) => {
                    if (!cell)
                        return;
                    let cellContent = processNodeContent(cell.content, renderChildren, options, indentLevel + 1).trim();
                    cellContent = cellContent.replace(/\|/g, '\\|');
                    if (cell.colId)
                        cellContent += ` <!-- ${cell.colId} -->`;
                    const colspan = Math.max(1, cell.colspan || 1);
                    const rowspan = Math.max(1, cell.rowspan || 1);
                    if (colspan > 1)
                        cellContent += ` <!-- colspan: ${colspan} -->`;
                    if (rowspan > 1)
                        cellContent += ` <!-- rowspan: ${rowspan} -->`;
                    rowString += `| ${cellContent} `;
                    currentColumn += colspan;
                    for (let i = 1; i < colspan; i++) {
                        rowString += '| ';
                    }
                });
                while (currentColumn < maxColumns) {
                    rowString += '|  ';
                    currentColumn++;
                }
                tableString += rowString + '|\n';
            });
            return tableString;
        },
        code: (node) => {
            const codeNode = node;
            const codeContent = codeNode.content || "";
            if (codeNode.inline) {
                return `\`${codeContent}\``;
            }
            else {
                return `\`\`\`${codeNode.language || ''}\n${codeContent}\n\`\`\`\n`;
            }
        },
        blockquote: (node, options, renderChildren, indentLevel) => {
            const rawBqContent = renderChildren(node.content, options, indentLevel);
            const processedBqContent = rawBqContent
                .trim()
                .split("\n")
                .map(line => `> ${line.trim()}`)
                .join("\n");
            if (processedBqContent.length > 0 && processedBqContent !== ">") {
                return processedBqContent + '\n';
            }
            return '> \n';
        },
        semanticHtml: (node, options, renderChildren, indentLevel) => {
            const htmlNode = node;
            const contentString = renderChildren(htmlNode.content, options, indentLevel);
            switch (htmlNode.htmlType) {
                case "article":
                    return contentString;
                case "section":
                    return `---\n\n${contentString}\n\n---\n`;
                case "summary":
                case "time":
                case "aside":
                case "nav":
                case "figcaption":
                case "main":
                case "mark":
                case "header":
                case "footer":
                case "details":
                case "figure":
                    return `<!-- <${htmlNode.htmlType}> -->\n${contentString}\n<!-- </${htmlNode.htmlType}> -->\n`;
                default:
                    // ignore
                    return undefined;
            }
        },
        // 'meta' is handled by markdownMetaASTToString, not here.
        // 'custom' is handled by options.renderCustomNode in the main loop.
    };
    const INLINE_NODE_TYPES = new Set(['text', 'bold', 'italic', 'strikethrough', 'link', 'code']);
    const BLOCK_NODE_TYPES = new Set(['heading', 'image', 'list', 'video', 'table', 'code', 'blockquote', 'semanticHtml']);
    function markdownContentASTToStringRecursive(nodes, options, indentLevel = 0) {
        let markdownString = '';
        const renderChildren = (childNodes, childOptions = options, childIndent = indentLevel) => {
            if (typeof childNodes === 'string')
                return childNodes;
            if (!childNodes || childNodes.length === 0)
                return '';
            return markdownContentASTToStringRecursive(childNodes, childOptions, childIndent);
        };
        nodes.forEach((node, index) => {
            if (node.type === 'meta')
                return;
            const nodeRenderingOverride = options?.overrideNodeRenderer?.(node, options, indentLevel);
            if (nodeRenderingOverride !== undefined) {
                markdownString += nodeRenderingOverride;
                return;
            }
            let renderedNodeString;
            if (nodeRenderers[node.type]) {
                renderedNodeString = nodeRenderers[node.type]?.(node, options, renderChildren, indentLevel);
            }
            else if (node.type === 'custom' && options?.renderCustomNode) {
                renderedNodeString = options.renderCustomNode(node, options, indentLevel);
            }
            else {
                console.warn(`Unhandled Markdown AST node type: ${node.type}`);
                renderedNodeString = '';
            }
            if (renderedNodeString === undefined || renderedNodeString === null) {
                renderedNodeString = '';
            }
            // --- Whitespace and Newline Management ---
            const isCurrentNodeInline = INLINE_NODE_TYPES.has(node.type) && !(node.type === 'code' && !(node).inline);
            const isCurrentNodeBlock = BLOCK_NODE_TYPES.has(node.type) && !(node.type === 'code' && (node).inline);
            if (isCurrentNodeInline) {
                let addSpaceBeforeCurrentNode = false;
                if (markdownString.length > 0 && renderedNodeString.length > 0) {
                    const lastCharOfPrevOutput = markdownString.slice(-1);
                    const firstCharOfCurrentRenderedNode = renderedNodeString.charAt(0);
                    const prevEndsWithSpace = /\s/.test(lastCharOfPrevOutput);
                    const currentStartsWithSpace = /\s/.test(firstCharOfCurrentRenderedNode);
                    // Punctuation that should not have a leading space if it's the start of the current node.
                    const currentStartsWithClingingPunctuation = /^[.,!?;:)]/.test(firstCharOfCurrentRenderedNode);
                    // Characters that the previous string might end with, that shouldn't have a following space.
                    const prevEndsWithOpeningBracket = /[([]$/.test(lastCharOfPrevOutput);
                    if (!prevEndsWithSpace &&
                        !currentStartsWithSpace &&
                        !currentStartsWithClingingPunctuation &&
                        !prevEndsWithOpeningBracket) {
                        addSpaceBeforeCurrentNode = true;
                    }
                }
                if (addSpaceBeforeCurrentNode) {
                    markdownString += ' ';
                }
                markdownString += renderedNodeString;
            }
            else if (isCurrentNodeBlock) {
                if (markdownString.length > 0 && !markdownString.endsWith('\n')) {
                    markdownString += '\n';
                }
                if (renderedNodeString.length > 0 && markdownString.length > 0 && !markdownString.endsWith('\n\n') && !renderedNodeString.startsWith('\n')) {
                    if (!markdownString.endsWith('\n'))
                        markdownString += '\n';
                }
                markdownString += renderedNodeString;
                if (renderedNodeString.length > 0 && index < nodes.length - 1) {
                    const nextNode = nodes[index + 1];
                    const isNextNodeBlock = BLOCK_NODE_TYPES.has(nextNode.type) && !(nextNode.type === 'code' && (nextNode).inline);
                    if (isNextNodeBlock || (nextNode.type === 'code' && !(nextNode).inline)) {
                        if (!renderedNodeString.endsWith('\n\n')) {
                            if (!renderedNodeString.endsWith('\n')) {
                                markdownString += '\n\n';
                            }
                            else {
                                markdownString += '\n';
                            }
                        }
                    }
                    else if (!renderedNodeString.endsWith('\n')) {
                        markdownString += '\n';
                    }
                }
            }
            else {
                markdownString += renderedNodeString;
            }
        });
        return markdownString;
    }
    // --- Main Export ---
    function markdownASTToString(nodes, options, indentLevel = 0) {
        if (!Array.isArray(nodes)) {
            console.warn("markdownASTToString received non-array input for nodes:", nodes);
            return "";
        }
        const metaOutput = markdownMetaASTToString(nodes, options);
        const contentOutput = markdownContentASTToStringRecursive(nodes, options, indentLevel);
        if (!metaOutput && !contentOutput) {
            return "";
        }
        if (contentOutput) {
            return (metaOutput + contentOutput).trimEnd();
        }
        else {
            return metaOutput;
        }
    }

    const debugMessage = (message) => {
    };
    /**
     * Attempts to find the main content of a web page.
     * @param document The Document object to search.
     * @returns The Element containing the main content, or the body if no main content is found.
     */
    function findMainContent(document) {
        const mainElement = document.querySelector('main') || document.querySelector('[role="main"]');
        if (mainElement) {
            return mainElement;
        }
        if (!document.body) {
            return document.documentElement;
        }
        return detectMainContent(document.body);
    }
    function wrapMainContent(mainContentElement, document) {
        if (mainContentElement.tagName.toLowerCase() !== 'main') {
            const mainElement = document.createElement('main');
            mainContentElement.before(mainElement);
            mainElement.appendChild(mainContentElement);
            mainElement.id = 'detected-main-content';
        }
    }
    function detectMainContent(rootElement) {
        const candidates = [];
        const minScore = 20;
        collectCandidates(rootElement, candidates, minScore);
        if (candidates.length === 0) {
            return rootElement;
        }
        candidates.sort((a, b) => calculateScore(b) - calculateScore(a));
        let bestIndependentCandidate = candidates[0];
        for (let i = 1; i < candidates.length; i++) {
            if (!candidates.some((otherCandidate, j) => j !== i && otherCandidate.contains(candidates[i]))) {
                if (calculateScore(candidates[i]) > calculateScore(bestIndependentCandidate)) {
                    bestIndependentCandidate = candidates[i];
                    debugMessage(`New best independent candidate found: ${elementToString(bestIndependentCandidate)}`);
                }
            }
        }
        debugMessage(`Final main content candidate: ${elementToString(bestIndependentCandidate)}`);
        return bestIndependentCandidate;
    }
    function elementToString(element) {
        if (!element) {
            return 'No element';
        }
        return `${element.tagName}#${element.id || 'no-id'}.${Array.from(element.classList).join('.')}`;
    }
    function collectCandidates(element, candidates, minScore) {
        const score = calculateScore(element);
        if (score >= minScore) {
            candidates.push(element);
            debugMessage(`Candidate found: ${elementToString(element)}, score: ${score}`);
        }
        Array.from(element.children).forEach(child => {
            collectCandidates(child, candidates, minScore);
        });
    }
    function calculateScore(element) {
        let score = 0;
        let scoreLog = [];
        // High impact attributes
        const highImpactAttributes = ['article', 'content', 'main-container', 'main', 'main-content'];
        highImpactAttributes.forEach(attr => {
            if (element.classList.contains(attr) || element.id === attr) {
                score += 10;
                scoreLog.push(`High impact attribute found: [${attr}] [${[...element.classList.values()].join(",")}], score increased by 10`);
            }
        });
        // High impact tags
        const highImpactTags = ['article', 'main', 'section'];
        if (highImpactTags.includes(element.tagName.toLowerCase())) {
            score += 5;
            scoreLog.push(`High impact tag found: [${element.tagName}], score increased by 5`);
        }
        // Paragraph count
        const paragraphCount = element.getElementsByTagName('p').length;
        const paragraphScore = Math.min(paragraphCount, 5);
        if (paragraphScore > 0) {
            score += paragraphScore;
            scoreLog.push(`Paragraph count: ${paragraphCount}, score increased by ${paragraphScore}`);
        }
        // Text content length
        const textContentLength = element.textContent?.trim().length || 0;
        if (textContentLength > 200) {
            const textScore = Math.min(Math.floor(textContentLength / 200), 5);
            score += textScore;
            scoreLog.push(`Text content length: ${textContentLength}, score increased by ${textScore}`);
        }
        // Link density
        const linkDensity = calculateLinkDensity(element);
        if (linkDensity < 0.3) {
            score += 5;
            scoreLog.push(`Link density: ${linkDensity.toFixed(2)}, score increased by 5`);
        }
        // Data attributes
        if (element.hasAttribute('data-main') || element.hasAttribute('data-content')) {
            score += 10;
            scoreLog.push('Data attribute for main content found, score increased by 10');
        }
        // Role attribute
        if (element.getAttribute('role')?.includes('main')) {
            score += 10;
            scoreLog.push('Role attribute indicating main content found, score increased by 10');
        }
        if (scoreLog.length > 0) {
            debugMessage(`Scoring for ${elementToString(element)}:`);
        }
        return score;
    }
    function calculateLinkDensity(element) {
        const linkLength = Array.from(element.getElementsByTagName('a'))
            .reduce((sum, link) => sum + (link.textContent?.length || 0), 0);
        const textLength = element.textContent?.length || 1; // Avoid division by zero
        return linkLength / textLength;
    }

    const mediaSuffixes = ["jpeg", "jpg", "png", "gif", "bmp", "tiff", "tif", "svg",
        "webp", "ico", "avi", "mov", "mp4", "mkv", "flv", "wmv", "webm", "mpeg",
        "mpg", "mp3", "wav", "aac", "ogg", "flac", "m4a", "pdf", "doc", "docx",
        "ppt", "pptx", "xls", "xlsx", "txt", "css", "js", "xml", "json",
        "html", "htm"
    ];
    const addRefPrefix = (prefix, prefixesToRefs) => {
        if (!prefixesToRefs[prefix]) {
            prefixesToRefs[prefix] = 'ref' + Object.values(prefixesToRefs).length;
        }
        return prefixesToRefs[prefix];
    };
    const processUrl = (url, prefixesToRefs) => {
        if (!url.startsWith('http')) {
            return url;
        }
        else {
            const mediaSuffix = url.split('.').slice(-1)[0];
            if (mediaSuffix && mediaSuffixes.includes(mediaSuffix)) {
                const parts = url.split('/'); // Split URL keeping the slash before text
                const prefix = parts.slice(0, -1).join('/'); // Get the prefix by removing last part
                const refPrefix = addRefPrefix(prefix, prefixesToRefs);
                return `${refPrefix}://${parts.slice(-1).join('')}`;
            }
            else {
                if (url.split('/').length > 4) {
                    return addRefPrefix(url, prefixesToRefs);
                }
                else {
                    return url;
                }
            }
        }
    };
    function refifyUrls(markdownElement, prefixesToRefs = {}) {
        if (Array.isArray(markdownElement)) {
            markdownElement.forEach(element => refifyUrls(element, prefixesToRefs));
        }
        else {
            switch (markdownElement.type) {
                case 'link':
                    markdownElement.href = processUrl(markdownElement.href, prefixesToRefs);
                    refifyUrls(markdownElement.content, prefixesToRefs);
                    break;
                case 'image':
                case 'video':
                    markdownElement.src = processUrl(markdownElement.src, prefixesToRefs);
                    break;
                case 'list':
                    markdownElement.items.forEach(item => item.content.forEach(_ => refifyUrls(_, prefixesToRefs)));
                    break;
                case 'table':
                    markdownElement.rows.forEach(row => row.cells.forEach(cell => typeof cell.content === 'string' ? null : refifyUrls(cell.content, prefixesToRefs)));
                    break;
                case 'blockquote':
                case 'semanticHtml':
                    refifyUrls(markdownElement.content, prefixesToRefs);
                    break;
            }
        }
        return prefixesToRefs;
    }

    const isNot = (tPred) => (t) => !tPred(t);
    const isString = (x) => typeof x === "string";
    function findInAST(markdownElement, checker) {
        const loopCheck = (z) => {
            for (const element of z) {
                const found = findInAST(element, checker);
                if (found) {
                    return found;
                }
            }
            return undefined;
        };
        if (Array.isArray(markdownElement)) {
            return loopCheck(markdownElement);
        }
        else {
            if (checker(markdownElement)) {
                return markdownElement;
            }
            switch (markdownElement.type) {
                case 'link':
                    return loopCheck(markdownElement.content);
                case 'list':
                    return loopCheck(markdownElement.items
                        .map(_ => _.content)
                        .flat());
                case 'table':
                    return loopCheck(markdownElement.rows
                        .map(row => row.cells.map(_ => _.content)
                        .filter(isNot(isString)))
                        .flat());
                case 'blockquote':
                case 'semanticHtml':
                    return loopCheck(markdownElement.content);
            }
            return undefined;
        }
    }
    function findAllInAST(markdownElement, checker) {
        const loopCheck = (z) => {
            let out = [];
            for (const element of z) {
                const found = findAllInAST(element, checker);
                out = [...out, ...found];
            }
            return out;
        };
        if (Array.isArray(markdownElement)) {
            return loopCheck(markdownElement);
        }
        else {
            if (checker(markdownElement)) {
                return [markdownElement];
            }
            switch (markdownElement.type) {
                case 'link':
                    return loopCheck(markdownElement.content);
                case 'list':
                    return loopCheck(markdownElement.items
                        .map(_ => _.content)
                        .flat());
                case 'table':
                    return loopCheck(markdownElement.rows
                        .map(row => row.cells.map(_ => _.content)
                        .filter(isNot(isString)))
                        .flat());
                case 'blockquote':
                case 'semanticHtml':
                    return loopCheck(markdownElement.content);
            }
            return [];
        }
    }

    /**
     * Converts an HTML string to Markdown.
     * @param html The HTML string to convert.
     * @param options Conversion options.
     * @returns The converted Markdown string.
     */
    function convertHtmlToMarkdown(html, options) {
        const parser = options?.overrideDOMParser ?? (typeof DOMParser !== 'undefined' ? new DOMParser() : null);
        if (!parser) {
            throw new Error('DOMParser is not available. Please provide an overrideDOMParser in options.');
        }
        const doc = parser.parseFromString(html, 'text/html');
        let element;
        if (options?.extractMainContent) {
            element = findMainContent(doc);
            if (options.includeMetaData && !!doc.querySelector('head')?.innerHTML && !element.querySelector('head')) {
                // content container was found and extracted, re-attaching the head for meta-data extraction
                element = parser.parseFromString(`<html>${doc.head.outerHTML}${element.outerHTML}`, 'text/html').documentElement;
            }
        }
        else {
            // If there's a body, use it; otherwise, use the document element
            if (options?.includeMetaData && !!doc.querySelector('head')?.innerHTML) {
                element = doc.documentElement;
            }
            else {
                element = doc.body || doc.documentElement;
            }
        }
        return convertElementToMarkdown(element, options);
    }
    /**
     * Converts an HTML Element to Markdown.
     * @param element The HTML Element to convert.
     * @param options Conversion options.
     * @returns The converted Markdown string.
     */
    function convertElementToMarkdown(element, options) {
        let ast = htmlToMarkdownAST(element, options);
        if (options?.refifyUrls) {
            options.urlMap = refifyUrls(ast);
        }
        return markdownASTToString(ast, options);
    }
    /**
     * Finds a node in the Markdown AST that matches the given predicate.
     * @param ast The Markdown AST to search.
     * @param predicate A function that returns true for the desired node.
     * @returns The first matching node, or undefined if not found.
     */
    function findInMarkdownAST(ast, predicate) {
        return findInAST(ast, predicate);
    }
    /**
     * Finds all nodes in the Markdown AST that match the given predicate.
     * @param ast The Markdown AST to search.
     * @param predicate A function that returns true for the desired nodes.
     * @returns An array of all matching nodes.
     */
    function findAllInMarkdownAST(ast, predicate) {
        return findAllInAST(ast, predicate);
    }

    exports.convertElementToMarkdown = convertElementToMarkdown;
    exports.convertHtmlToMarkdown = convertHtmlToMarkdown;
    exports.findAllInMarkdownAST = findAllInMarkdownAST;
    exports.findInMarkdownAST = findInMarkdownAST;
    exports.findMainContent = findMainContent;
    exports.htmlToMarkdownAST = htmlToMarkdownAST;
    exports.markdownASTToString = markdownASTToString;
    exports.refifyUrls = refifyUrls;
    exports.wrapMainContent = wrapMainContent;

    return exports;

    return exports;
  })();

  /* ══════════════════════════════════════════
     STANDALONE SCRAPER — Smart Agent v7.9 (updated)

     ΕΚΠΑΙΔΕΥΣΗ AGENT — Γνώση από έρευνα:

     ΤΥΠΟΙ SITES ΠΟΥ ΣΥΝΑΝΤΑ:

     1. CUSTOM SPA (React/Vue/Next.js/Angular)
        Αναγνωρίστε: URL με /#/, /app/, React devtools, __NEXT_DATA__
        API patterns: /api/menu, /api/catalog, /api/products, /api/categories
        Συμπεριφορά: Φορτώνει data από API κατά page load ή ανά navigation
        Παράδειγμα: order.gyradiko.gr/#/catalog, lartigiano.gr/menu/*

     2. GLORIAFOOD (πολύ συνηθισμένο στην Ελλάδα)
        Αναγνωρίστε: gloriafood.com embed, "gloriafood" στο DOM/scripts
        API: api.gloriafood.com/menu/{restaurantId} ή widget.gloriafood.com
        Data format: {categories:[{name, items:[{name,price,description,options}]}]}

     3. UPMENU
        Αναγνωρίστε: order.upmenu.com/{slug} ή upmenu embed
        API: /api/menus/ ή /api/categories, /api/products
        Data format: {data:{categories:[], products:[]}}

     4. E-TABLE (Delivery Hero Greece)
        Αναγνωρίστε: e-table.gr domain
        API: api.e-table.gr/v2/restaurants/{id}/menu

     5. WORDPRESS + PLUGIN (WooCommerce, Food Menu plugin)
        Αναγνωρίστε: wp-content στο HTML, /wp-json/ endpoints
        API: /wp-json/wc/v3/products ή /wp-json/food-menu/v1/items
        Fallback: DOM scraping (static HTML)

     6. WIX
        Αναγνωρίστε: wix.com domain, _api στο URL
        API: _api/wix-restaurants-menus/v2/menus

     7. STATIC HTML (WordPress χωρίς plugin, custom HTML)
        Αναγνωρίστε: Δεν υπάρχουν API calls, content ορατό αμέσως
        Στρατηγική: DOM scraping μόνο

     8. SQUARESPACE
        Αναγνωρίστε: squarespace.com, static.squarespace.com assets
        API: /api/open/GetOrderPage ή /api/open/GetMenuDetails

     ΣΗΜΑΝΤΙΚΟ — SPA initial load timing:
        Τα SPAs κάνουν API calls κατά το ΑΡΧΙΚΟ page load
        Ο interceptor πρέπει να τρέχει και να περιμένει NETWORK IDLE
        Network idle = δεν υπάρχουν pending requests για 500ms
        Αν δεν περιμένεις → χάνεις το κύριο data call

     ΑΝΑΓΝΩΡΙΣΗ ΠΛΑΤΦΟΡΜΑΣ:
        window.__NEXT_DATA__ → Next.js SPA
        window.__nuxt__ → Nuxt.js SPA
        window.__REACT_QUERY_GLOBAL_STORE__ → React Query
        document.querySelector('#__NEXT_DATA__') → Next.js SSR
        /wp-json/ στο network log → WordPress
        gloriafood στο DOM → GloriaFood
        upmenu στο DOM/URL → UpMenu
        e-table.gr domain → E-table
        wix.com → Wix

  ══════════════════════════════════════════ */
  const standalone = {

    EDGE_FN:  'https://gxrybwnufjhoymsclxla.supabase.co/functions/v1/extract-catalog',
    SUPA_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd4cnlid251Zmpob3ltc2NseGxhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODIxMzg0NzksImV4cCI6MjA5NzcxNDQ3OX0.Z5fCjFdp42-sGcNAEZyD22YQdUxSbktlhy3VCMChAPQ',

    // ══════════════════════════════════════════════════════
    //  UTILITIES — αναλλοίωτα από v8.2
    // ══════════════════════════════════════════════════════

    async injectInterceptor() {
      if (window.__efoodInterceptorActive) return;
      window.__efoodInterceptorActive = true;
      window.__efoodIntercepted = window.__efoodIntercepted || [];
      window.__efoodPendingRequests = 0;
      return new Promise(resolve => {
        try {
          chrome.runtime.sendMessage({ type: 'injectInterceptor' }, resp => {
            if (chrome.runtime.lastError) console.warn('[efood] Interceptor:', chrome.runtime.lastError.message);
            resolve(resp);
          });
          setTimeout(() => resolve(null), 3000);
        } catch(e) { resolve(null); }
      });
    },

    async waitNetworkIdle(timeoutMs=4000, idleMs=600) {
      const start = Date.now();
      let lastActivity = Date.now();
      return new Promise(resolve => {
        const check = () => {
          const pending = window.__efoodPendingRequests || 0;
          if (pending === 0) {
            if (Date.now() - lastActivity >= idleMs) { resolve(); return; }
          } else {
            lastActivity = Date.now();
          }
          if (Date.now() - start >= timeoutMs) { resolve(); return; }
          setTimeout(check, 100);
        };
        setTimeout(check, 200);
      });
    },

    detectPlatform() {
      const url = location.href;
      const html = document.documentElement.innerHTML.slice(0, 5000);
      const scripts = [...document.querySelectorAll('script[src]')].map(s=>s.src).join(' ');

      if (/gloriafood\.com/i.test(html+scripts)) return 'gloriafood';
      if (/upmenu\.com|order\.upmenu/i.test(url+html)) return 'upmenu';
      if (/e-table\.gr/i.test(url)) return 'e-table';
      if (/wix\.com|static\.parastorage/i.test(html+scripts)) return 'wix';
      if (/squarespace\.com/i.test(html+scripts)) return 'squarespace';
      if (window.__NEXT_DATA__ || document.getElementById('__NEXT_DATA__')) return 'nextjs';
      if (window.__nuxt__ || window.__NUXT__) return 'nuxt';
      if (/wp-content|wp-json/i.test(html)) return 'wordpress';
      if (/angular|ng-version/i.test(html+scripts)) return 'angular_spa';
      if (url.includes('/#/') || url.includes('#/')) return 'spa_hash';
      return 'unknown';
    },

    getPageStructure(platform) {
      const navLinks = [...document.querySelectorAll(
        'nav a,[role="navigation"] a,[class*="nav"] a,[class*="tab"] a,[class*="categor"] a,[class*="sidebar"] a,[data-test-id*="navigation"] a'
      )].slice(0,30).map(a=>({
        text: a.textContent.trim().slice(0,50),
        href: (a.getAttribute('href')||'').slice(0,100)
      })).filter(a=>a.text&&a.text.length>1);

      const priceRx = /\d+[.,]\d+\s*€|€\s*\d+|\d+\s*€/;
      const prices = [...document.querySelectorAll('*')]
        .filter(el=>el.children.length===0&&priceRx.test(el.textContent))
        .slice(0,10).map(el=>el.textContent.trim().slice(0,40));

      const schema = [];
      document.querySelectorAll('script[type="application/ld+json"]').forEach(s=>{
        try { const d=JSON.parse(s.textContent); schema.push({type:d['@type'],keys:Object.keys(d).slice(0,8)}); }
        catch(e){}
      });

      const mRx=/menu|catalog|product|item|categor|assortment|food|price/i;
      const sRx=/analytics|pixel|gtm|facebook|\.png|\.jpg|\.css|woff/i;
      const networkEndpoints = performance.getEntriesByType('resource')
        .filter(e=>mRx.test(e.name)&&!sRx.test(e.name)&&(e.initiatorType==='fetch'||e.initiatorType==='xmlhttprequest'))
        .map(e=>({url:e.name.slice(0,200),duration:Math.round(e.duration),type:e.initiatorType}))
        .slice(0,20);

      const intercepted = (window.__efoodIntercepted||[]).map((c,i)=>({
        index:i, url:c.url.slice(0,150),
        method:c.method, size:c.size,
        keys:Object.keys(c.data||{}).slice(0,12)
      }));

      const platformHints = {};
      if (platform === 'nextjs' && window.__NEXT_DATA__) {
        try { platformHints.nextData = JSON.stringify(window.__NEXT_DATA__).slice(0,500); } catch(e){}
      }
      if (platform === 'wordpress') {
        platformHints.wpJsonEndpoints = networkEndpoints.filter(e=>e.url.includes('wp-json')).map(e=>e.url);
      }

      return {
        url: location.href,
        title: document.title.slice(0,80),
        platform,
        navLinks: [...new Map(navLinks.map(l=>[l.text,l])).values()],
        samplePrices: [...new Set(prices)].slice(0,8),
        hasPrices: prices.length>0,
        schema,
        interceptedCalls: intercepted,
        networkEndpoints,
        platformHints,
        itemCount: document.querySelectorAll('[class*="product"],[class*="item"],[class*="card"],[class*="menu-item"]').length
      };
    },

    async probe(structure) {
      const results = [];

      for (const call of structure.interceptedCalls) {
        const captured = (window.__efoodIntercepted||[])[call.index];
        if (!captured?.data) continue;
        const analysis = standalone.analyzeData(captured.data, call.url);
        results.push({ source:'intercepted', index:call.index, url:call.url, size:call.size, ...analysis });
      }

      const probedUrls = new Set(structure.interceptedCalls.map(c=>c.url));
      for (const ep of structure.networkEndpoints.slice(0,8)) {
        if (probedUrls.has(ep.url)) continue;
        try {
          const r = await fetch(ep.url, {credentials:'include',cache:'no-store'});
          if (!r.ok) { results.push({source:'network',url:ep.url,status:r.status,hasData:false}); continue; }
          const ct = r.headers.get('content-type')||'';
          if (ct.includes('json')) {
            const data = await r.json();
            const analysis = standalone.analyzeData(data, ep.url);
            results.push({source:'network',url:ep.url,status:200,...analysis});
          } else {
            results.push({source:'network',url:ep.url,status:200,hasData:false,reason:'not JSON'});
          }
        } catch(e) { results.push({source:'network',url:ep.url,error:e.message,hasData:false}); }
      }

      if (structure.platform === 'gloriafood') {
        const wid = document.querySelector('[data-restaurant-id],[data-widget-id]');
        if (wid) {
          const rid = wid.dataset.restaurantId || wid.dataset.widgetId;
          if (rid) {
            try {
              const r = await fetch(`https://api.gloriafood.com/menu/${rid}`, {credentials:'include'});
              if (r.ok) {
                const data = await r.json();
                results.push({source:'gloriafood_api',url:`/api/menu/${rid}`,status:200,...standalone.analyzeData(data,'gloriafood'),data});
              }
            } catch(e) {}
          }
        }
      }

      if (structure.platform === 'wordpress') {
        const base = location.origin;
        const wpEndpoints = [
          '/wp-json/wc/store/v1/products?per_page=100',
          '/wp-json/wc/v3/products?per_page=100',
          '/wp-json/food-menu/v1/items',
          '/wp-json/wp/v2/posts?categories=menu&per_page=100'
        ];
        for (const ep of wpEndpoints) {
          try {
            const r = await fetch(base+ep, {credentials:'include'});
            if (r.ok && r.headers.get('content-type')?.includes('json')) {
              const data = await r.json();
              const arr = Array.isArray(data) ? data : data.data || [];
              if (arr.length > 0) {
                results.push({source:'wordpress_api',url:base+ep,status:200,...standalone.analyzeData({items:arr},ep),data:{items:arr}});
                break;
              }
            }
          } catch(e) {}
        }
      }

      if (structure.platform === 'squarespace') {
        try {
          const jsonUrl = location.href.split('?')[0] + '?format=json-pretty';
          const r = await fetch(jsonUrl, {credentials:'include'});
          if (r.ok) {
            const data = await r.json();
            const items = data.items || data.collection?.items || data.page?.items || [];
            if (items.length > 0) {
              results.push({source:'squarespace_json',url:jsonUrl,status:200,...standalone.analyzeData({items},jsonUrl),data:{items}});
            }
          }
        } catch(e) {}
      }

      if (structure.platform === 'wix') {
        const orgIdMatch = document.body.innerHTML.match(/organizationId['":,\s]+["']?(\d{10,})/);
        const orgId = orgIdMatch?.[1];
        if (orgId) {
          try {
            const r = await fetch(`https://api.wixrestaurants.com/v2/organizations/${orgId}/menu`, {credentials:'include'});
            if (r.ok) {
              const data = await r.json();
              results.push({source:'wix_api',url:`/v2/organizations/${orgId}/menu`,status:200,...standalone.analyzeData(data,'wix'),data});
            }
          } catch(e) {}
        }
      }

      results.push({
        source:'dom', hasData:structure.hasPrices, itemCount:structure.itemCount,
        hasCategories:structure.navLinks.length>0,
        dataQuality:structure.hasPrices?'partial':'empty',
        reason:structure.hasPrices?`${structure.itemCount} items ορατά`:'Δεν υπάρχουν τιμές'
      });

      return results;
    },

    analyzeData(data, url='') {
      if (!data||typeof data!=='object') return {hasData:false,reason:'not object'};
      const checks = {hasCategories:false,hasItems:false,categoryCount:0,itemCount:0,dataQuality:'none',topLevelKeys:Object.keys(data).slice(0,12)};

      const tryNested = (obj) => {
        if (!obj||typeof obj!=='object') return;
        const catKeys = ['categories','menu','sections','groups','hasMenuSection'];
        for (const k of catKeys) {
          if (Array.isArray(obj[k])&&obj[k].length>0) {
            checks.hasCategories=true; checks.categoryCount=obj[k].length;
            const fc=obj[k][0];
            if (fc?.items?.length||fc?.item_ids?.length||fc?.products?.length||fc?.hasMenuItem?.length) {
              checks.hasItems=true;
              checks.itemCount=obj[k].reduce((s,c)=>s+(c.items?.length||c.item_ids?.length||c.products?.length||c.hasMenuItem?.length||0),0);
            }
            return;
          }
        }
        const itemKeys = ['items','products','results','data','menu_items','menuItems'];
        for (const k of itemKeys) {
          if (Array.isArray(obj[k])&&obj[k].length>0) {
            const f=obj[k][0];
            if (f?.name||f?.title||f?.price!==undefined||f?.baseprice!==undefined) {
              checks.hasItems=true; checks.itemCount=obj[k].length; return;
            }
          }
        }
      };

      tryNested(data);
      if (!checks.hasItems&&data.payload) tryNested(data.payload);
      if (!checks.hasItems&&data.data) tryNested(data.data);
      if (!checks.hasItems&&data.result) tryNested(data.result);
      if (!checks.hasItems&&data.menu) tryNested(data.menu);

      if (checks.hasCategories&&checks.hasItems) checks.dataQuality='full_catalog';
      else if (checks.hasItems) checks.dataQuality='items_only';
      else if (checks.hasCategories) checks.dataQuality='categories_only';
      else checks.dataQuality='no_catalog_data';

      checks.hasData=checks.hasItems||checks.hasCategories;
      return checks;
    },

    async fetchUrl(url,method='GET',body=null,headers={}) {
      try {
        const opts={method,credentials:'include',headers:{'Content-Type':'application/json',...headers}};
        if(body) opts.body=JSON.stringify(body);
        const r=await fetch(url,opts);
        if(!r.ok) return {error:`HTTP ${r.status}`,url};
        const ct=r.headers.get('content-type')||'';
        if(ct.includes('json')){const data=await r.json();return {url,size:JSON.stringify(data).length,data};}
        const text=await r.text();
        return {url,size:text.length,preview:text.slice(0,300)};
      } catch(e){return {error:e.message,url};}
    },

    getInteractiveElements() {
      const results = [];
      let idx = 0;
      const navSelectors = [
        '[role="tab"]', '[role="menuitem"]', '[role="option"]',
        '[role="treeitem"]', '[role="listitem"]',
        'nav a', 'nav button', 'nav li',
        '[class*="tab"]', '[class*="categor"]', '[class*="nav-item"]',
        '[class*="sidebar"] li', '[class*="menu-item"]',
        '[class*="section-link"]', '[class*="category-link"]',
        'aside a', 'aside li', 'aside button'
      ];
      const seen = new Set();
      const priceRx = /\d+[.,]\d+\s*€|€\s*\d+/;

      for (const sel of navSelectors) {
        try {
          document.querySelectorAll(sel).forEach(el => {
            if (seen.has(el)) return;
            const text = el.textContent.trim().replace(/\s+/g,' ').slice(0,60);
            if (!text || text.length < 2) return;
            if (priceRx.test(text)) return;
            if (/^(€|\d+[.,]\d+)/.test(text)) return;
            seen.add(el);
            const rect = el.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0) return;
            const role = el.getAttribute('role') ||
              (el.tagName==='A'?'link':el.tagName==='BUTTON'?'button':'item');
            const selected = el.getAttribute('aria-selected')==='true' ||
              el.classList.toString().includes('active') ||
              el.classList.toString().includes('selected') ||
              el.classList.toString().includes('current');
            results.push({ idx, role, text, selected, tag: el.tagName.toLowerCase(),
              x: Math.round(rect.left + rect.width/2), y: Math.round(rect.top + rect.height/2),
              w: Math.round(rect.width), h: Math.round(rect.height) });
            el.__efoodIdx = idx;
            idx++;
          });
        } catch(e) {}
      }
      return results;
    },

    async clickElement(idx) {
      let target = null;
      const all = document.querySelectorAll('*');
      for (const el of all) { if (el.__efoodIdx === idx) { target = el; break; } }
      if (!target) return { error: `Element #${idx} not found` };
      const text = target.textContent.trim().slice(0, 50);
      const before = (window.__efoodIntercepted||[]).length;
      target.click();
      await sleep(1800);
      const after = (window.__efoodIntercepted||[]).length;
      return { clicked: text, idx, newIntercepted: after - before, url: location.href };
    },

    async clickCategory(text) {
      const candidates=[...document.querySelectorAll(
        'nav a,[role="navigation"] a,[class*="nav"] a,[class*="tab"] a,[class*="categor"] a,[class*="menu"] a'
      )];
      const target=candidates.find(el=>el.textContent.trim().toLowerCase().includes(text.toLowerCase()));
      if(!target) return {error:`Δεν βρέθηκε: "${text}"`};
      const before=(window.__efoodIntercepted||[]).length;
      target.click();
      await sleep(1600);
      const after=(window.__efoodIntercepted||[]).length;
      return {clicked:target.textContent.trim(),newIntercepted:after-before,url:location.href};
    },

    getDom(selector=null) {
      let md='';
      try {
        const el=selector?document.querySelector(selector):document.body;
        md=htmlToSMD.convertElementToMarkdown(el||document.body,{
          extractMainContent:true,refifyUrls:false,includeMetaData:false,
          overrideElementProcessing:(el)=>{
            const cls=(el.className||'').toString().toLowerCase();
            if(/cookie|popup|modal|cart|login|newsletter|social|banner|advertisement/.test(cls)) return [];
            return null;
          }
        });
      } catch(e){md=document.body.innerText;}
      if(md.length>12000) md=md.slice(0,12000)+'\n[...truncated...]';
      return {markdown:md,length:md.length};
    },

    // ══════════════════════════════════════════════════════
    //  EMBEDDED STATE EXTRACTOR → structured data από page globals
    // ══════════════════════════════════════════════════════
    extractEmbeddedState() {
      const candidates = [];

      // __NEXT_DATA__
      try {
        const nd = window.__NEXT_DATA__ || JSON.parse(document.getElementById('__NEXT_DATA__')?.textContent||'null');
        if (nd) candidates.push({ source: '__NEXT_DATA__', data: nd, priority: 10 });
      } catch(e) {}

      // __NUXT__
      try {
        if (window.__NUXT__) candidates.push({ source: '__NUXT__', data: window.__NUXT__, priority: 9 });
      } catch(e) {}

      // Apollo cache
      try {
        const apollo = window.__APOLLO_STATE__ || window.__APOLLO_CLIENT__?.cache?.data?.data;
        if (apollo) candidates.push({ source: 'apollo', data: apollo, priority: 8 });
      } catch(e) {}

      // JSON-LD schema.org
      document.querySelectorAll('script[type="application/ld+json"]').forEach(s => {
        try {
          const d = JSON.parse(s.textContent);
          if (d['@type'] && /Menu|Restaurant|FoodEstablishment|ItemList|Product/.test(d['@type'])) {
            candidates.push({ source: 'json-ld', data: d, priority: 7 });
          }
        } catch(e) {}
      });

      // Inline scripts με catalog data
      document.querySelectorAll('script:not([src])').forEach(s => {
        const t = s.textContent;
        if (t.length < 100 || t.length > 500000) return;
        const m = t.match(/(?:window\.__\w+|var \w+)\s*=\s*(\{[\s\S]{200,}?\});?\s*(?:\/\/|$|\n)/);
        if (m) {
          try {
            const parsed = JSON.parse(m[1]);
            const analysis = standalone.analyzeData(parsed, 'inline_script');
            if (analysis.hasData) candidates.push({ source: 'inline_script', data: parsed, priority: 6 });
          } catch(e) {}
        }
      });

      if (candidates.length === 0) return null;

      // Επέλεξε καλύτερο candidate
      candidates.sort((a,b) => b.priority - a.priority);
      for (const c of candidates) {
        const analysis = standalone.analyzeData(c.data, c.source);
        if (analysis.hasData && analysis.dataQuality !== 'no_catalog_data') {
          // Μετατροπή σε structured IR nodes
          return standalone.dataToNodes(c.data, c.source);
        }
      }
      return null;
    },

    // ══════════════════════════════════════════════════════
    //  DATA → CANONICAL NODES
    //  Μετατρέπει structured API/JSON data σε node array
    //  Χωρίς semantic labels — μόνο facts
    // ══════════════════════════════════════════════════════
    dataToNodes(data, source) {
      const nodes = [];
      let id = 0;

      const addNode = (text, parentId, meta={}) => {
        const nodeId = ++id;
        nodes.push({ id: nodeId, parentId: parentId || null, text: String(text).slice(0,200), ...meta, source });
        return nodeId;
      };

      const tryExtract = (obj) => {
        if (!obj || typeof obj !== 'object') return false;

        // Format: {categories:[{name, items:[{name, price, description, options}]}]}
        const cats = obj.categories || obj.menu?.categories || obj.data?.categories ||
                     obj.payload?.categories || obj.sections || obj.groups || [];
        if (Array.isArray(cats) && cats.length > 0) {
          for (const cat of cats) {
            const catName = cat.name || cat.title || '';
            if (!catName) continue;
            const catId = addNode(catName, null, { nodeType: 'group', chars: catName.length });
            const items = cat.items || cat.products || cat.hasMenuItem || cat.menu_items || [];
            for (const item of items) {
              const iName = item.name || item.title || '';
              if (!iName) continue;
              const rawPrice = item.price ?? item.baseprice ?? item.finalPrice ?? null;
              const price = rawPrice != null
                ? (typeof rawPrice === 'number' && rawPrice > 500 ? (rawPrice/100).toFixed(2) : String(rawPrice))
                : null;
              const desc = (item.description || item.info?.el || '').slice(0,200);
              const itemId = addNode(iName, catId, {
                nodeType: 'entry',
                price,
                description: desc || null,
                chars: iName.length + (desc?.length||0)
              });
              // Options
              const opts = item.options || item.selections || item.modifiers || [];
              for (const og of opts) {
                const ogName = og.name || og.title || 'Επιλογές';
                const ogId = addNode(ogName, itemId, { nodeType: 'option_group' });
                const vals = og.values || og.options || og.choices || [];
                for (const v of vals) {
                  const vName = v.name || v.title || '';
                  const vPrice = v.price != null ? String(v.price > 500 ? (v.price/100).toFixed(2) : v.price) : null;
                  addNode(vName, ogId, { nodeType: 'option', price: vPrice });
                }
              }
            }
          }
          return true;
        }

        // Format: flat items array
        const items = obj.items || obj.products || obj.results || [];
        if (Array.isArray(items) && items.length > 0) {
          const first = items[0];
          if (first?.name || first?.title || first?.price !== undefined) {
            // Group by category if available
            const byCategory = new Map();
            for (const item of items) {
              const catName = item.categories?.[0]?.name || item.category || 'Προϊόντα';
              if (!byCategory.has(catName)) byCategory.set(catName, []);
              byCategory.get(catName).push(item);
            }
            for (const [catName, catItems] of byCategory) {
              const catId = addNode(catName, null, { nodeType: 'group', chars: catName.length });
              for (const item of catItems) {
                const iName = item.name || item.title || '';
                if (!iName) continue;
                const rawPrice = item.price ?? item.baseprice ?? null;
                const price = rawPrice != null ? String(rawPrice > 500 ? (rawPrice/100).toFixed(2) : rawPrice) : null;
                addNode(iName, catId, {
                  nodeType: 'entry',
                  price,
                  description: (item.description || item.short_description || '').replace(/<[^>]+>/g,'').slice(0,200) || null,
                  chars: iName.length
                });
              }
            }
            return true;
          }
        }

        return false;
      };

      if (!tryExtract(data)) {
        // Try nested
        for (const key of ['payload','data','result','menu','catalog']) {
          if (data[key] && tryExtract(data[key])) break;
        }
      }

      return nodes;
    },

    // ══════════════════════════════════════════════════════
    //  CANONICAL IR — lossless DOM → node array
    //  Κανένα semantic label (SECTION/ITEM/OPTION_GROUP)
    //  Μόνο structural facts: tag, depth, text, price, style hints
    // ══════════════════════════════════════════════════════
    buildCanonicalIR(rootEl) {
      rootEl = rootEl || document.body;
      const nodes = [];
      let id = 0;

      const skipTags = new Set(['SCRIPT','STYLE','SVG','PATH','META','LINK','NOSCRIPT',
        'IFRAME','INPUT','SELECT','TEXTAREA','HEAD']);
      const noiseClasses = /cookie|gdpr|newsletter|social|banner|footer|copyright|powered.?by|modal|popup|cart|login/i;
      const priceRx = /(\d+[.,]\d+)\s*€|€\s*(\d+[.,]\d+)/;
      const seen = new Set();

      const getStyleHints = (el) => {
        const hints = {};
        try {
          const cs = window.getComputedStyle(el);
          const fs = parseFloat(cs.fontSize);
          if (!isNaN(fs)) hints.fontSize = Math.round(fs);
          const fw = cs.fontWeight;
          if (fw === 'bold' || parseInt(fw) >= 600) hints.bold = true;
          if (cs.textAlign === 'center') hints.centered = true;
          const mt = parseFloat(cs.marginTop);
          if (!isNaN(mt) && mt > 12) hints.marginTop = Math.round(mt);
        } catch(e) {}
        return hints;
      };

      const walk = (el, depth, parentId) => {
        if (!el || el.nodeType !== 1) return;
        if (skipTags.has(el.tagName)) return;

        const cls = (el.className||'').toString().toLowerCase();
        const elId = (el.id||'').toLowerCase();
        if (noiseClasses.test(cls + elId)) return;

        const text = (el.innerText || el.textContent || '').trim().replace(/\s+/g,' ');
        if (!text || text.length < 2) return;

        // Αποφυγή duplicates για nested elements με ίδιο text
        const textKey = `${depth}:${text.slice(0,80)}`;
        if (seen.has(textKey)) return;

        const priceMatch = text.match(priceRx);
        const price = priceMatch ? (priceMatch[1]||priceMatch[2]).replace(',','.') : null;
        const isLeaf = el.children.length === 0;
        const isHeading = /^H[1-6]$/.test(el.tagName);

        // Structural metadata — purely observational
        const meta = {
          tag: el.tagName.toLowerCase(),
          depth,
          chars: text.length,
        };
        if (price) meta.price = price;
        if (isHeading) meta.heading = parseInt(el.tagName[1]);
        if (el.tagName === 'LI') meta.listItem = true;
        if (el.tagName === 'TD' || el.tagName === 'TH') meta.tableCell = true;

        // Style hints — αντικειμενικά, όχι ερμηνεία
        const styleHints = getStyleHints(el);
        if (Object.keys(styleHints).length > 0) meta.style = styleHints;

        // Αν έχει παιδιά → είναι container node
        if (!isLeaf && el.children.length > 0) {
          // Emit container μόνο αν έχει δικό του text (όχι μόνο από παιδιά)
          const directText = [...el.childNodes]
            .filter(n => n.nodeType === 3)
            .map(n => n.textContent.trim())
            .join(' ').trim();

          if (directText.length > 2) {
            seen.add(textKey);
            const nodeId = ++id;
            nodes.push({ id: nodeId, parentId: parentId || null, text: directText.slice(0,200), ...meta });
            for (const child of el.children) walk(child, depth+1, nodeId);
          } else {
            // Container χωρίς direct text — διατρέχουμε παιδιά με τον ίδιο parentId
            for (const child of el.children) walk(child, depth, parentId);
          }
          return;
        }

        // Leaf node
        if (text.length >= 2 && text.length <= 500) {
          seen.add(textKey);
          const nodeId = ++id;
          nodes.push({ id: nodeId, parentId: parentId || null, text: text.slice(0,200), ...meta });
        }
      };

      try { walk(rootEl, 0, null); } catch(e) {}
      return nodes;
    },

    // ══════════════════════════════════════════════════════
    //  EXECUTION PLANNER
    //  Input:  node array (canonical IR)
    //  Output: [{chunkId, nodeIds, estimatedTokens}]
    //  Κόβει μόνο σε φυσικά boundaries (depth=0 nodes = top-level containers)
    //  Δεν γνωρίζει τι είναι category/item/option
    // ══════════════════════════════════════════════════════
    planExecution(nodes, maxTokensPerChunk=6000) {
      if (nodes.length === 0) return [];

      // Εκτίμηση tokens: Greek text ~2 chars/token, overhead ~1.3x
      const estimateTokens = (nodeList) => {
        const chars = nodeList.reduce((s, n) => s + (n.chars || n.text?.length || 20) + 30, 0);
        return Math.ceil(chars / 2 * 1.3);
      };

      // Βρες top-level nodes (depth=0 ή depth=1) ως φυσικά boundaries
      const minDepth = Math.min(...nodes.map(n => n.depth || 0));
      const boundaryDepth = minDepth + 1;

      // Ομαδοποίηση nodes ανά boundary parent
      const boundaries = [];
      let currentBoundary = { nodes: [], rootNode: null };

      for (const node of nodes) {
        const nodeBoundaryDepth = node.depth !== undefined ? node.depth : 0;
        if (nodeBoundaryDepth <= boundaryDepth && currentBoundary.nodes.length > 0) {
          boundaries.push(currentBoundary);
          currentBoundary = { nodes: [], rootNode: null };
        }
        if (nodeBoundaryDepth <= boundaryDepth) currentBoundary.rootNode = node;
        currentBoundary.nodes.push(node);
      }
      if (currentBoundary.nodes.length > 0) boundaries.push(currentBoundary);

      // Συνένωση μικρών boundaries σε chunks που χωράνε στο token limit
      const chunks = [];
      let currentChunk = { chunkId: 1, nodeIds: [], nodes: [], estimatedTokens: 0 };

      for (const boundary of boundaries) {
        const boundaryTokens = estimateTokens(boundary.nodes);
        if (currentChunk.nodeIds.length > 0 && currentChunk.estimatedTokens + boundaryTokens > maxTokensPerChunk) {
          chunks.push({ chunkId: currentChunk.chunkId, nodeIds: currentChunk.nodeIds, estimatedTokens: currentChunk.estimatedTokens });
          currentChunk = { chunkId: chunks.length + 1, nodeIds: [], nodes: [], estimatedTokens: 0 };
        }
        for (const n of boundary.nodes) currentChunk.nodeIds.push(n.id);
        currentChunk.nodes.push(...boundary.nodes);
        currentChunk.estimatedTokens += boundaryTokens;
      }
      if (currentChunk.nodeIds.length > 0) {
        chunks.push({ chunkId: currentChunk.chunkId, nodeIds: currentChunk.nodeIds, estimatedTokens: currentChunk.estimatedTokens });
      }

      return chunks;
    },

    // ══════════════════════════════════════════════════════
    //  SERIALIZE CHUNK
    //  Μετατρέπει node subset σε record-based text για Claude
    //  Format: NODE id | TAG | DEPTH | TEXT | [PRICE] | [STYLE]
    //  Χωρίς JSON syntax, χωρίς semantic labels
    // ══════════════════════════════════════════════════════
    serializeChunk(nodes, chunkNodeIds) {
      const nodeMap = new Map(nodes.map(n => [n.id, n]));
      const lines = [];

      for (const nodeId of chunkNodeIds) {
        const n = nodeMap.get(nodeId);
        if (!n) continue;

        const parts = [`NODE ${n.id}`];
        parts.push(`TAG ${n.tag || 'div'}`);
        parts.push(`DEPTH ${n.depth || 0}`);
        if (n.heading) parts.push(`HEADING ${n.heading}`);
        if (n.listItem) parts.push('LIST_ITEM');
        if (n.tableCell) parts.push('TABLE_CELL');
        parts.push(`TEXT ${n.text}`);
        if (n.price) parts.push(`PRICE ${n.price}`);
        if (n.style) {
          const styleStr = Object.entries(n.style).map(([k,v])=>`${k}=${v}`).join(' ');
          parts.push(`STYLE ${styleStr}`);
        }
        if (n.parentId) parts.push(`PARENT ${n.parentId}`);
        if (n.source) parts.push(`SOURCE ${n.source}`);

        lines.push(parts.join(' | '));
      }

      return lines.join('\n');
    },

    // ══════════════════════════════════════════════════════
    //  MERGE RESULTS
    //  Συνενώνει αποτελέσματα από πολλαπλά Claude calls
    //  Dedup ανά category name + item name
    // ══════════════════════════════════════════════════════
    mergeResults(resultSets) {
      const catMap = new Map();
      for (const cats of resultSets) {
        if (!Array.isArray(cats)) continue;
        for (const cat of cats) {
          if (!cat?.name || !cat?.items?.length) continue;
          const key = cat.name.trim().toLowerCase();
          if (!catMap.has(key)) catMap.set(key, { name: cat.name, items: [] });
          const ex = catMap.get(key);
          for (const item of cat.items) {
            if (!item?.name) continue;
            if (!ex.items.some(i => i.name?.toLowerCase() === item.name?.toLowerCase())) {
              ex.items.push(item);
            }
          }
        }
      }
      return [...catMap.values()].filter(c => c.items.length > 0);
    },

    // ══════════════════════════════════════════════════════
    //  CALL EDGE FUNCTION
    //  Στέλνει serialized chunk στο Supabase → Claude
    // ══════════════════════════════════════════════════════
    async callEdge(storeName, serializedText) {
      const r = await fetch(this.EDGE_FN, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${this.SUPA_KEY}` },
        body: JSON.stringify({ mode: 'nodes', storeName, nodes: serializedText })
      });
      if (!r.ok) {
        const errText = await r.text().catch(()=>'');
        throw new Error(`Edge ${r.status}: ${errText.slice(0,200)}`);
      }
      const d = await r.json();
      if (d.error) throw new Error(d.error);
      return d.categories || [];
    },

    isLikelyCategory(el) {
      const text = (el.innerText||el.textContent||'').trim().replace(/\s+/g,' ');
      if (!text || text.length < 2) return false;
      if (/\d+[.,]\d+\s*€|€\s*\d+/.test(text)) return false;
      if (text.length > 80) return false;
      if (/cookie|login|register|cart|wishlist|search|share|follow|subscribe|όροι|privacy|cookies/i.test(text)) return false;
      const role = el.getAttribute('role')||'';
      if (role === 'tab' || role === 'menuitem') return true;
      const cls = (el.className||'').toString().toLowerCase();
      if (/categor|nav-item|tab|section-link|menu-cat|sidebar/i.test(cls)) return true;
      const parent = el.closest('nav,[role="navigation"],[class*="sidebar"],[class*="nav"],[class*="tab"]');
      if (parent && text.length < 40) return true;
      return false;
    },

    // ══════════════════════════════════════════════════════
    //  MAIN RUN — νέο pipeline v9
    // ══════════════════════════════════════════════════════
    async run() {
      const storeName = document.title || location.hostname;
      const _t0 = Date.now();
      const diag = {
        url: location.href, store_name: storeName,
        started: new Date().toISOString(),
        platform: null, sources: [], chunks: [],
        extract: { method: null, total_nodes: 0, chunks_sent: 0, claude_cats: 0, claude_items: 0, error: null },
        errors: [], timing: {}, final: {}
      };
      window.__efoodDiag = diag;

      setSt('🔍 Init...', 3);
      this.injectInterceptor();

      const platform = this.detectPlatform();
      diag.platform = platform;
      setSt(`🔍 Platform: ${platform}`, 6);

      window.scrollTo(0, Math.min(400, document.body.scrollHeight));
      await this.waitNetworkIdle(4000, 600);
      window.scrollTo(0, 0);
      await sleep(300);
      diag.timing.network_idle_ms = Date.now() - _t0;

      // ── ΦΑΣΗ 1: Συλλογή nodes από όλες τις πηγές ────────
      let allNodes = [];

      // 1a. Embedded state (Next.js, Nuxt, Apollo, JSON-LD, inline scripts)
      setSt('🧠 Embedded state...', 12);
      try {
        const stateNodes = this.extractEmbeddedState();
        if (stateNodes && stateNodes.length > 0) {
          allNodes.push(...stateNodes);
          diag.sources.push({ type: 'embedded_state', nodes: stateNodes.length });
          setSt(`🧠 State: ${stateNodes.length} nodes`, 18);
        }
      } catch(e) { diag.errors.push({ step: 'embedded_state', message: e.message }); }

      // 1b. Probe — known platform APIs + intercepted calls
      setSt(`🧪 Probe [${platform}]...`, 22);
      try {
        const structure = this.getPageStructure(platform);
        diag.timing.structure_ms = Date.now() - _t0;
        const probeResults = await this.probe(structure);
        const goodProbes = probeResults.filter(p => p.hasData && p.dataQuality !== 'no_catalog_data' && p.data);

        for (const p of goodProbes) {
          const probeNodes = this.dataToNodes(p.data, p.source || p.url?.slice(0,60) || 'api');
          if (probeNodes.length > 0) {
            // Offset IDs για να μην συγκρούονται με existing nodes
            const offset = allNodes.length > 0 ? Math.max(...allNodes.map(n=>n.id)) : 0;
            probeNodes.forEach(n => { n.id += offset; if (n.parentId) n.parentId += offset; });
            allNodes.push(...probeNodes);
            diag.sources.push({ type: 'probe_api', url: p.url?.slice(0,80), nodes: probeNodes.length });
          }
        }
        setSt(`🧪 Probe: ${goodProbes.length} πηγές`, 36);
        diag.timing.probe_ms = Date.now() - _t0;
      } catch(e) { diag.errors.push({ step: 'probe', message: e.message }); }

      // 1c. DOM Canonical IR — πάντα τρέχει, lossless
      setSt('📄 DOM IR...', 42);
      try {
        const domNodes = this.buildCanonicalIR(document.body);
        if (domNodes.length > 0) {
          const offset = allNodes.length > 0 ? Math.max(...allNodes.map(n=>n.id)) : 0;
          domNodes.forEach(n => { n.id += offset; if (n.parentId) n.parentId += offset; });
          allNodes.push(...domNodes);
          diag.sources.push({ type: 'dom_ir', nodes: domNodes.length });
          setSt(`📄 DOM: ${domNodes.length} nodes`, 50);
        }
      } catch(e) { diag.errors.push({ step: 'dom_ir', message: e.message }); }

      // 1d. Selective clicks — αν δεν έχουμε αρκετά structured data
      const structuredNodes = allNodes.filter(n => n.price || n.nodeType === 'entry');
      if (structuredNodes.length < 10) {
        setSt('👆 Selective clicks...', 55);
        try {
          const elements = this.getInteractiveElements();
          const catEls = elements.filter(el => {
            let domEl = null;
            for (const e of document.querySelectorAll('*')) { if (e.__efoodIdx === el.idx) { domEl = e; break; } }
            return domEl ? this.isLikelyCategory(domEl) : false;
          }).slice(0, 12);

          for (let i = 0; i < catEls.length; i++) {
            if (stopped()) break;
            const el = catEls[i];
            setSt(`👆 [${i+1}/${catEls.length}] "${el.text.slice(0,25)}"`, 55 + Math.round((i/Math.max(catEls.length,1))*15));

            let domEl = null;
            for (const e of document.querySelectorAll('*')) { if (e.__efoodIdx === el.idx) { domEl = e; break; } }
            const href = domEl?.getAttribute?.('href');
            const isAnchor = href && !href.startsWith('#') && !href.startsWith('javascript');

            if (isAnchor) {
              try {
                const fullUrl = href.startsWith('http') ? href : location.origin + href;
                const r = await fetch(fullUrl, { credentials: 'include' });
                if (r.ok) {
                  const html = await r.text();
                  const tmp = document.createElement('div');
                  tmp.innerHTML = html.replace(/<script[\s\S]*?<\/script>/gi,'').replace(/<style[\s\S]*?<\/style>/gi,'');
                  const fetchNodes = this.buildCanonicalIR(tmp);
                  if (fetchNodes.length > 0) {
                    const offset = allNodes.length > 0 ? Math.max(...allNodes.map(n=>n.id)) : 0;
                    fetchNodes.forEach(n => { n.id += offset; if (n.parentId) n.parentId += offset; n.source = `fetch:${el.text}`; });
                    allNodes.push(...fetchNodes);
                    diag.sources.push({ type: 'fetch_click', text: el.text, nodes: fetchNodes.length });
                  }
                }
              } catch(e) {}
            } else {
              const beforeCalls = (window.__efoodIntercepted||[]).length;
              await this.clickElement(el.idx);
              await sleep(800);
              const newCalls = (window.__efoodIntercepted||[]).slice(beforeCalls);
              for (const c of newCalls) {
                const analysis = this.analyzeData(c.data, c.url);
                if (analysis.hasData && c.data) {
                  const clickNodes = this.dataToNodes(c.data, `click:${el.text}`);
                  if (clickNodes.length > 0) {
                    const offset = allNodes.length > 0 ? Math.max(...allNodes.map(n=>n.id)) : 0;
                    clickNodes.forEach(n => { n.id += offset; if (n.parentId) n.parentId += offset; });
                    allNodes.push(...clickNodes);
                    diag.sources.push({ type: 'click_api', text: el.text, nodes: clickNodes.length });
                  }
                }
              }
              // DOM μετά από click
              const clickDomNodes = this.buildCanonicalIR(document.body);
              if (clickDomNodes.length > 0) {
                const offset = allNodes.length > 0 ? Math.max(...allNodes.map(n=>n.id)) : 0;
                clickDomNodes.forEach(n => { n.id += offset; if (n.parentId) n.parentId += offset; n.source = `click_dom:${el.text}`; });
                allNodes.push(...clickDomNodes);
              }
            }
          }
        } catch(e) { diag.errors.push({ step: 'clicks', message: e.message }); }
        diag.timing.clicks_ms = Date.now() - _t0;
      }

      diag.extract.total_nodes = allNodes.length;
      setSt(`🔀 ${allNodes.length} nodes → Planning...`, 72);

      // ── ΦΑΣΗ 2: Execution Planning + Extract ─────────────
      if (allNodes.length === 0) {
        throw new Error('Δεν βρέθηκαν δεδομένα σε καμία πηγή.');
      }

      const chunks = this.planExecution(allNodes, 6000);
      diag.extract.chunks_sent = chunks.length;
      setSt(`🤖 ${chunks.length} chunk(s) → Claude...`, 78);

      const resultSets = [];
      for (let i = 0; i < chunks.length; i++) {
        if (stopped()) break;
        const chunk = chunks[i];
        setSt(`🤖 Chunk ${i+1}/${chunks.length} (~${chunk.estimatedTokens} tokens)...`, 78 + Math.round((i/chunks.length)*18));
        try {
          const serialized = this.serializeChunk(allNodes, chunk.nodeIds);
          const cats = await this.callEdge(storeName, serialized);
          resultSets.push(cats);
          diag.chunks.push({ chunkId: chunk.chunkId, nodes: chunk.nodeIds.length, tokens: chunk.estimatedTokens, cats: cats.length });
        } catch(e) {
          diag.errors.push({ step: `chunk_${chunk.chunkId}`, message: e.message });
          diag.chunks.push({ chunkId: chunk.chunkId, error: e.message });
        }
        diag.timing.last_chunk_ms = Date.now() - _t0;
      }

      // ── ΦΑΣΗ 3: Merge ────────────────────────────────────
      const catalog = this.mergeResults(resultSets).map(cat => ({
        name: cat.name,
        items: (cat.items||[]).map(it => ({
          name: it.name,
          price: it.price ?? null,
          description: it.description || null,
          confidence: it.confidence || 'high',
          notes: it.notes || null,
          option_groups: it.option_groups || []
        }))
      }));

      const total = catalog.reduce((s,c) => s + c.items.length, 0);
      diag.extract.claude_cats = catalog.length;
      diag.extract.claude_items = total;
      diag.extract.method = 'canonical_ir_v9';
      diag.final = { categories: catalog.length, items: total, duration_ms: Date.now() - _t0 };
      diag.timing.total_ms = Date.now() - _t0;
      diag.ended = new Date().toISOString();

      setSt(`✅ ${catalog.length} κατηγορίες · ${total} items [v9/${platform}]`, 99);
      return { catalog, source: 'standalone' };
    }
  };
;
;
;;;;;

  /* ══════════════════════════════════════════
     FINISH — κοινός κώδικας για download
  ══════════════════════════════════════════ */
  function finish(catalog, source, startTime) {
    const endTime   = new Date();
    const totalItems = catalog.reduce((s,c) => s + c.items.length, 0);
    const totalOpts  = catalog.reduce((s,c) => c.items.reduce((ss,it) => ss + (it.option_groups||[]).reduce((sss,g) => sss + (g.options||[]).length, 0), s), 0);
    const isPartial  = window.__efoodStop === true;

    // Venue slug από URL για filename
    const slug = location.pathname.match(/\/venue\/([^/?#]+)/)?.[1]
              || location.pathname.match(/\/restaurant\/([^/?#]+)/)?.[1]
              || location.pathname.match(/\/delivery\/[^/]+\/([^/?#]+)/)?.[1]
              || location.hostname.replace('www.','');

    const durationSec = startTime ? Math.round((endTime - startTime) / 1000) : null;
    const startStr    = startTime ? formatTimestamp(startTime) : null;
    const endStr      = formatTimestamp(endTime);
    const fileTs      = formatFilename(endTime);

    const output = {
      categories: catalog.map(c => ({
        name: c.name,
        items: c.items.map(({btn, card, ...rest}) => ({
          ...rest,
          confidence: rest.confidence || 'high',
          notes: rest.notes || null
        }))
      })),
      _ts: Date.now(),
      _source: source,
      _url: location.href,
      _partial: isPartial,
      _timing: {
        started:  startStr,
        ended:    endStr,
        duration_seconds: durationSec
      }
    };

    const label = isPartial
      ? `⏹ Μερική εξαγωγή — ${totalItems} προϊόντα · ${catalog.length} κατηγορίες`
      : `✓ ${totalItems} προϊόντα · ${totalOpts} επιλογές · ${catalog.length} κατηγορίες · ${durationSec}s`;
    setSt(label, 100);

    // Κρύβουμε το warning και το STOP button
    const warn = document.getElementById('__ef_warn');
    if(warn) warn.style.display = 'none';
    const stopBtn = document.getElementById('__ef_stop_btn');
    if(stopBtn) stopBtn.style.display = 'none';

    // Filename: woltRetail_nespresso-boutique_28-06-2026_23-45.json
    const filename = `${source}_${slug}_${fileTs}.json`;

    // Download + Close buttons
    const bd = document.createElement('div');
    bd.style.marginTop = '12px';
    const dl = document.createElement('button');
    dl.textContent = '⬇ Κατέβασε JSON';
    dl.style.cssText = 'background:#f5b800;color:#0f0f0f;border:none;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer;font-size:13px;';
    dl.onclick = function() {
      const blob = new Blob([JSON.stringify(output, null, 2)], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = filename;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    };
    const cl = document.createElement('button');
    cl.textContent = 'Κλείσιμο';
    cl.style.cssText = 'background:#333;color:#fff;border:none;border-radius:8px;padding:8px 14px;font-weight:600;cursor:pointer;font-size:13px;margin-left:6px;';
    cl.onclick = () => ov.remove();
    bd.appendChild(dl); bd.appendChild(cl);

    // Diagnostic κουμπί — για standalone
    if(source === 'standalone') {
      const diagBtn = document.createElement('button');
      diagBtn.textContent = '🔍 Diagnostic';
      diagBtn.style.cssText = 'background:#1e40af;color:#fff;border:none;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer;font-size:13px;margin-left:6px;';
      diagBtn.onclick = function() {
        const diag = window.__efoodDiag || { error: 'Δεν βρέθηκε diagnostic object' };
        // Πρόσθεσε και το catalog output στο diagnostic
        diag._catalog_output = output.categories.map(c => ({
          name: c.name,
          item_count: c.items.length,
          items_sample: c.items.slice(0,3).map(i=>({ name:i.name, price:i.price, confidence:i.confidence }))
        }));
        const blob = new Blob([JSON.stringify(diag, null, 2)], {type:'application/json'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const diagFilename = `diagnostic_standalone_${slug}_${fileTs}.json`;
        a.href = url; a.download = diagFilename;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 2000);
        diagBtn.textContent = '✅ Κατεβήκε';
      };
      bd.appendChild(diagBtn);
    }

    // Diagnostic κουμπί — μόνο για woltRetail
    if(source === 'woltRetail') {
      const diagBtn = document.createElement('button');
      diagBtn.textContent = '🔍 Diagnostic';
      diagBtn.style.cssText = 'background:#1e40af;color:#fff;border:none;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer;font-size:13px;margin-left:6px;';
      diagBtn.onclick = async function() {
        diagBtn.disabled = true;
        diagBtn.textContent = '⏳ Τρέχει...';

        try {
          const diagSlug = slug; // ήδη υπολογισμένο στο finish()
          const diagFilename = `diagnostic_${diagSlug}_${formatFilename(new Date())}.json`;
          const startMs = Date.now();

          // ── ΦΑΣΗ 1: Ανάλυση output που ήδη έχουμε ──
          const cats = output.categories || [];
          const totalItems = cats.reduce((s,c) => s + (c.items||[]).length, 0);
          const gtinCount  = cats.reduce((s,c) => s + (c.items||[]).filter(i=>i.gtin).length, 0);
          const descCount  = cats.reduce((s,c) => s + (c.items||[]).filter(i=>i.description).length, 0);

          // Κατηγορίες με 0 items (ύποπτο — μπορεί να χάθηκαν)
          const emptyCats = cats.filter(c => (c.items||[]).length === 0).map(c=>c.name);

          // Πρώτα 3 itemIds από το output (πριν αφαιρεθούν τα _itemId)
          // Εφόσον τα _itemId έχουν ήδη αφαιρεθεί, τα παίρνουμε από DOM
          const domIds = [];
          document.querySelectorAll('[data-test-id="ItemCard"]').forEach(card => {
            const href = card.querySelector('a[href*="itemid"]')?.href || '';
            const m = href.match(/itemid-([a-f0-9]+)/);
            if(m && !domIds.includes(m[1])) domIds.push(m[1]);
          });

          // ── ΦΑΣΗ 2: Checks — τρέχουν ΜΟΝΟ αν κάτι φαίνεται άσχημο ──
          const issues = []; // προβλήματα που βρήκαμε
          const warnings = []; // μη-κρίσιμα

          // Coverage warnings (δεν είναι errors — μπορεί να είναι φυσιολογικό)
          if(totalItems === 0)
            issues.push('Το scraping επέστρεψε 0 items — κάτι έσπασε στο scrolling ή στις κατηγορίες');
          if(emptyCats.length > 0)
            warnings.push(`${emptyCats.length} κατηγορίες με 0 items: ${emptyCats.join(', ')}`);
          if(totalItems > 0 && gtinCount === 0)
            issues.push('0% GTIN — το enrichment δεν τρέχει ή το assortment API δεν επέστρεψε barcodes');
          if(totalItems > 0 && descCount === 0)
            issues.push('0% descriptions — το enrichment δεν τρέχει');

          // ── ΦΑΣΗ 3: Αν υπάρχουν issues → τρέξε διαγνωστικά ──
          let tokenCheck = null, apiCheck = null, domCheck = null;

          const needsDeepCheck = issues.length > 0 || totalItems === 0;

          if(needsDeepCheck) {
            // Token check
            let token = null;
            try {
              const raw = document.cookie.split(';').map(c=>c.trim())
                .find(c=>c.startsWith('__wtoken='))?.split('=')?.[1];
              if(raw) {
                const obj = JSON.parse(decodeURIComponent(raw));
                token = obj.accessToken || null;
                let expiry = null;
                if(token) {
                  try {
                    const payload = JSON.parse(atob(token.split('.')[1]));
                    expiry = payload.exp ? new Date(payload.exp*1000).toISOString() : null;
                  } catch(e) {}
                }
                tokenCheck = { found: !!token, expiry_utc: expiry };
              } else {
                tokenCheck = { found: false, expiry_utc: null };
                issues.push('Token (__wtoken cookie) δεν βρέθηκε — ο χρήστης δεν είναι logged in στο Wolt');
              }
            } catch(e) {
              tokenCheck = { found: false, error: e.message };
              issues.push('Token parse error: ' + e.message);
            }

            // DOM check
            const cards    = document.querySelectorAll('[data-test-id="ItemCard"]');
            const navLinks = document.querySelectorAll('[data-test-id="navigation-bar-link"]');
            const titles   = document.querySelectorAll('[data-test-id="ImageCentricProductCard.Title"]');
            domCheck = {
              item_cards_visible: cards.length,
              nav_links_visible: navLinks.length,
              title_selectors_visible: titles.length,
              item_ids_in_dom: domIds.length
            };
            if(cards.length === 0)
              issues.push('ItemCard selector [data-test-id="ItemCard"] — 0 αποτελέσματα. Wolt άλλαξε DOM;');
            if(navLinks.length === 0)
              issues.push('Navigation links selector — 0 αποτελέσματα. Wolt άλλαξε DOM;');

            // Assortment API check — μόνο αν έχουμε token και IDs
            if(token && domIds.length > 0) {
              const testIds = domIds.slice(0, 3);
              try {
                const resp = await fetch(
                  `https://consumer-api.wolt.com/consumer-api/consumer-assortment/v1/venues/slug/${diagSlug}/assortment/items`,
                  {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                    body: JSON.stringify({ item_ids: testIds })
                  }
                );
                const apiItems = resp.ok ? (await resp.json()).items || [] : [];
                apiCheck = {
                  status: resp.status,
                  test_ids_sent: testIds.length,
                  items_returned: apiItems.length,
                  has_id_field:           apiItems.length > 0 && 'id'           in apiItems[0],
                  has_barcode_gtin_field:  apiItems.length > 0 && 'barcode_gtin' in apiItems[0],
                  has_description_field:   apiItems.length > 0 && 'description'  in apiItems[0]
                };
                if(!resp.ok)
                  issues.push(`Assortment API HTTP ${resp.status} — token λήξε ή endpoint άλλαξε`);
                else if(apiItems.length === 0)
                  issues.push('Assortment API επέστρεψε 0 items — τα IDs δεν ανήκουν σε αυτό το venue;');
                else {
                  if(!apiCheck.has_id_field)          issues.push('Field "id" λείπει από assortment response — schema άλλαξε!');
                  if(!apiCheck.has_barcode_gtin_field) issues.push('Field "barcode_gtin" λείπει — schema άλλαξε!');
                  if(!apiCheck.has_description_field)  issues.push('Field "description" λείπει — schema άλλαξε!');
                }
              } catch(e) {
                apiCheck = { error: e.message };
                issues.push('Assortment API exception: ' + e.message);
              }
            } else if(!token) {
              apiCheck = { skipped: 'token not found' };
            } else {
              apiCheck = { skipped: 'no item IDs available' };
              issues.push('Δεν βρέθηκαν itemIds στο DOM — αδύνατος ο έλεγχος API');
            }
          }

          // ── REPORT ──
          const report = {
            timestamp: formatTimestamp(new Date()),
            url: location.href,
            venue_slug: diagSlug,
            overall_status: issues.length === 0 ? 'OK' : 'ERROR',
            duration_ms: Date.now() - startMs,

            scraping_summary: {
              total_categories: cats.length,
              total_items: totalItems,
              gtin_count: gtinCount,
              gtin_pct: totalItems > 0 ? Math.round(gtinCount/totalItems*100) : 0,
              desc_count: descCount,
              desc_pct: totalItems > 0 ? Math.round(descCount/totalItems*100) : 0,
              partial: output._partial,
              timing: output._timing,
              empty_categories: emptyCats
            },

            issues,
            warnings,
            deep_checks_ran: needsDeepCheck,

            // Τα παρακάτω υπάρχουν ΜΟΝΟ αν τρέχτηκε deep check
            token: tokenCheck,
            dom: domCheck,
            assortment_api: apiCheck
          };

          // Download
          const blob = new Blob([JSON.stringify(report, null, 2)], {type:'application/json'});
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url; a.download = diagFilename;
          document.body.appendChild(a); a.click(); document.body.removeChild(a);
          setTimeout(() => URL.revokeObjectURL(url), 2000);

          // Αποθήκευση στο chrome.storage
          try { chrome.storage.local.set({ efood_last_diagnostic: { report, filename: diagFilename } }); } catch(e) {}

          if(issues.length === 0) {
            diagBtn.textContent = `✅ OK`;
          } else {
            diagBtn.textContent = `❌ ${issues.length} issues`;
          }

        } catch(e) {
          diagBtn.textContent = '❌ Σφάλμα';
          console.error('Diagnostic error:', e);
        }
      };
      bd.appendChild(diagBtn);
    }

    ov.appendChild(bd);
    window.__efoodScraping = false;
  }

  /* ── TIMESTAMP UTILITY (Europe/Athens) ── */
  function formatTimestamp(date) {
    return date.toLocaleString('el-GR', {
      timeZone: 'Europe/Athens',
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
      hour12: false
    }).replace(',', '');
  }

  function formatFilename(date) {
    const parts = date.toLocaleString('el-GR', {
      timeZone: 'Europe/Athens',
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: false
    });
    // "28/06/2026, 23:45" → "28-06-2026_23-45"
    return parts.replace(', ', '_').replace(/\//g, '-').replace(':', '-');
  }

  /* ══════════════════════════════════════════
     MAIN
  ══════════════════════════════════════════ */
  async function main() {
    const _startTime = new Date();
    window.__efoodStartTime = _startTime;
    try {
      let result;
      if(PLATFORM === 'woltRetail')  result = await woltRetail.run();
      else if(PLATFORM === 'wolt')   result = await wolt.run();
      else if(PLATFORM === 'box')    result = await box.run();
      else                           result = await standalone.run();

      finish(result.catalog, result.source, _startTime);
    } catch(e) {
      setSt('❌ Σφάλμα: ' + e.message, 0);
      console.error(e);
      window.__efoodScraping = false;
    }
  }

  main();
})();
