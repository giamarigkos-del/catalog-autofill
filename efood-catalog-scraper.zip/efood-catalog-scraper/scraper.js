(function(){
  if(window.__efoodScraping){alert('Τρέχει ήδη...');return;}
  window.__efoodScraping=true;

  /* ── PLATFORM DETECTION ── */
  const host=location.hostname;
  const PLATFORM=
    host.includes('wolt.com') ? 'wolt' :
    host.includes('box.gr')   ? 'box'  :
    'standalone';

  /* ── UI ── */
  const ov=document.createElement('div');
  ov.id='__efood_ov';
  ov.style.cssText='position:fixed;top:16px;right:16px;z-index:999999;background:#0f0f0f;color:#fff;padding:16px 20px;border-radius:12px;font-family:Inter,sans-serif;font-size:14px;min-width:300px;box-shadow:0 4px 24px #0006;';
  const platformLabel={wolt:'Wolt',box:'Box',standalone:'Standalone'}[PLATFORM];
  ov.innerHTML=`
    <div style="font-weight:700;margin-bottom:8px;font-size:15px;">⚡ efood Catalog Scraper <span style="font-size:11px;background:#333;padding:2px 7px;border-radius:20px;margin-left:4px;">${platformLabel}</span></div>
    <div style="background:#b45309;border-radius:8px;padding:10px 12px;margin-bottom:10px;font-size:12.5px;line-height:1.6;">
      <div style="font-weight:700;margin-bottom:4px;">⚠️ ΣΗΜΑΝΤΙΚΟ — ΜΗΝ:</div>
      <div>• Αλλάξεις tab ή παράθυρο</div>
      <div>• Κάνεις scroll με το ποντίκι</div>
      <div>• Κλικάρεις οπουδήποτε στη σελίδα</div>
      <div style="margin-top:6px;font-weight:600;">Ο scraper ελέγχει τη σελίδα μόνος του!</div>
    </div>
    <div id="__ef_st">Ξεκινάω...</div>
    <div style="margin-top:10px;height:4px;background:#333;border-radius:2px;"><div id="__ef_bar" style="height:4px;background:#f5b800;border-radius:2px;width:0%;transition:width .3s;"></div></div>`;
  document.body.appendChild(ov);

  const setSt=(m,p)=>{
    const el=document.getElementById('__ef_st');
    if(el)el.textContent=m;
    if(p!==undefined){const b=document.getElementById('__ef_bar');if(b)b.style.width=p+'%';}
  };
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));

  /* ══════════════════════════════════════════
     WOLT SCRAPER
  ══════════════════════════════════════════ */
  const wolt={
    isModalOpen:()=>!!document.querySelector('[role="dialog"] h2'),

    closeModal(){
      document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
    },

    getModalOptions(){
      const grps=[];
      document.querySelectorAll('[role="dialog"] fieldset').forEach(fs=>{
        const leg=fs.querySelector('legend');if(!leg)return;
        const title=(leg.querySelector('span')||leg).textContent.trim();if(!title)return;
        const type=fs.querySelector('input[type="radio"]')?'required_single':'optional_multi';
        const opts=[];
        fs.querySelectorAll('label').forEach(lbl=>{
          const ne=lbl.querySelector('.n1h7omf3')||lbl.querySelector('span');
          const name=ne?ne.textContent.trim():lbl.textContent.trim();
          if(!name||name.length>100)return;
          let pd=0;const pm=lbl.textContent.match(/\+(\d+[,\.]\d+)\s*€/);
          if(pm)pd=parseFloat(pm[1].replace(',','.'));
          opts.push({name,price_delta:pd});
        });
        if(opts.length)grps.push({title,type,options:opts});
      });
      return grps;
    },

    scanCatalog(){
      const catalog=[];
      document.querySelectorAll('[data-test-id="MenuSection"]').forEach(section=>{
        const titleDiv=section.querySelector('[data-test-id="MenuSectionTitle"]');
        const h2=titleDiv?titleDiv.querySelector('h2'):null;
        const catName=h2?h2.textContent.trim():'Γενικά';
        const items=[];
        section.querySelectorAll('[data-test-id="horizontal-item-card"]').forEach(card=>{
          const btn=card.querySelector('[data-test-id="horizontal-item-card-button"]');
          const h3=card.querySelector('[data-test-id="horizontal-item-card-header"]');
          const name=h3?h3.textContent.trim():'';
          if(!name)return;
          let price=null;
          const priceEl=card.querySelector('[data-test-id="horizontal-item-card-discounted-price"]')||
                        card.querySelector('[data-test-id="horizontal-item-card-price"]');
          if(priceEl){const pm=priceEl.textContent.trim().match(/€\s*(\d+[\.,]?\d*)/);if(pm)price=parseFloat(pm[1].replace(',','.')); }
          if(price===null){const pm=card.textContent.match(/€\s*(\d+[\.,]\d+)/)||card.textContent.match(/€\s*(\d+)/);if(pm)price=parseFloat(pm[1].replace(',','.')); }
          let description=null;
          card.querySelectorAll('p').forEach(p=>{const t=p.textContent.trim();if(t&&t!==name&&!t.includes('€')&&t.length>2&&!description)description=t;});
          items.push({name,price,description,btn,option_groups:[]});
        });
        if(items.length>0)catalog.push({name:catName,items});
      });
      return catalog;
    },

    async collectOptions(catalog){
      let total=0,done=0;
      catalog.forEach(c=>total+=c.items.length);
      for(const cat of catalog){
        for(const item of cat.items){
          done++;
          setSt(`Options ${done}/${total}: ${item.name.slice(0,28)}...`,Math.round(done/total*85)+10);
          if(!item.btn||!document.body.contains(item.btn)){item.option_groups=[];continue;}
          item.btn.click();
          let w=0;while(!wolt.isModalOpen()&&w<2000){await sleep(100);w+=100;}
          if(wolt.isModalOpen()){
            item.option_groups=wolt.getModalOptions();
            wolt.closeModal();
            w=0;while(wolt.isModalOpen()&&w<1000){await sleep(100);w+=100;}
            await sleep(200);
          } else {item.option_groups=[];}
        }
      }
    },

    async run(){
      setSt('Φορτώνω κατηγορίες...',2);
      let lastH=0,att=0;
      while(att<30){window.scrollTo(0,document.body.scrollHeight);await sleep(600);const h=document.body.scrollHeight;if(h===lastH)break;lastH=h;att++;}
      window.scrollTo(0,0);await sleep(500);
      setSt('Σαρώνω κατάλογο...',8);
      const catalog=wolt.scanCatalog();
      const total=catalog.reduce((s,c)=>s+c.items.length,0);
      setSt(`${catalog.length} κατηγορίες, ${total} προϊόντα — συλλέγω options...`,10);
      await sleep(300);
      await wolt.collectOptions(catalog);
      return {catalog,source:'wolt'};
    }
  };

  /* ══════════════════════════════════════════
     BOX SCRAPER
  ══════════════════════════════════════════ */
  const box={
    isModalOpen:()=>!!document.querySelector('product-myo'),

    closeModal(){
      // Κουμπί κλεισίματος του product-myo
      const closeBtn=document.querySelector('product-myo button[aria-label="Close"]');
      if(closeBtn){closeBtn.click();return;}
      document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
    },

    getModalOptions(){
      const grps=[];
      document.querySelectorAll('product-myo .product-myo-selection').forEach(sel=>{
        const titleEl=sel.querySelector('.product-myo-selection-header .box-typography-subtitle');
        const title=titleEl?titleEl.textContent.trim():'';
        if(!title)return;
        // radio group = required_single, checkbox = optional_multi
        const isRadio=!!sel.querySelector('mat-radio-button');
        const type=isRadio?'required_single':'optional_multi';
        const opts=[];
        sel.querySelectorAll('product-myo-choice').forEach(choice=>{
          const nameEl=choice.querySelector('.product-myo-choice-title');
          const priceEl=choice.querySelector('.product-myo-choice-price');
          const name=nameEl?nameEl.textContent.trim():'';
          if(!name)return;
          let pd=0;
          if(priceEl){
            const txt=priceEl.textContent.trim();
            const pm=txt.match(/(\d+[,\.]\d+)\s*€/);
            if(pm){
              pd=parseFloat(pm[1].replace(',','.'));
              // Αν δεν έχει "+" prefix, είναι η βασική τιμή (required_single base price) → pd=0
              if(!txt.includes('+'))pd=0;
            }
          }
          opts.push({name,price_delta:pd});
        });
        if(opts.length)grps.push({title,type,options:opts});
      });
      return grps;
    },

    // Διαβάζει τα ορατά cards και τα προσθέτει στο Map (merge by name)
    scanVisible(itemMap){
      document.querySelectorAll('section.shop-menu-items-category').forEach(section=>{
        const h2=section.querySelector('h2.shop-menu-items-category-name');
        const catName=h2?h2.textContent.trim():'Γενικά';
        section.querySelectorAll('.food-product-component').forEach(card=>{
          const nameEl=card.querySelector('.box-typography-body-m-bold');
          const name=nameEl?nameEl.textContent.trim():'';
          if(!name)return;
          if(itemMap.has(name))return; // ήδη έχουμε αυτό το προϊόν
          let price=null;
          const priceEl=card.querySelector('span.food-item-price');
          if(priceEl){
            const pm=priceEl.textContent.trim().match(/(\d+[,\.]\d+)\s*€/);
            if(pm)price=parseFloat(pm[1].replace(',','.'));
          }
          // Description από το card
          let description=null;
          const descEl=card.querySelector('.food-item-description');
          if(descEl){const t=descEl.textContent.trim();if(t)description=t;}
          itemMap.set(name,{name,price,description,catName,card,option_groups:[]});
        });
      });
    },

    // Χτίζει το catalog από το Map διατηρώντας κατηγορίες
    buildCatalog(itemMap){
      const catMap=new Map();
      for(const item of itemMap.values()){
        if(!catMap.has(item.catName)) catMap.set(item.catName,[]);
        catMap.get(item.catName).push(item);
      }
      return [...catMap.entries()].map(([name,items])=>({name,items}));
    },

    async collectOptions(catalog,container){
      let total=0,done=0;
      catalog.forEach(c=>total+=c.items.length);
      for(const cat of catalog){
        for(const item of cat.items){
          done++;
          setSt(`Options ${done}/${total}: ${item.name.slice(0,28)}...`,Math.round(done/total*85)+10);

          // Scroll το container ώστε να είναι ορατό το card
          if(item.card&&document.body.contains(item.card)){
            item.card.scrollIntoView({block:'center'});
            await sleep(300);
          }

          if(!item.card||!document.body.contains(item.card)){item.option_groups=[];continue;}
          item.card.click();
          let w=0;while(!box.isModalOpen()&&w<3000){await sleep(100);w+=100;}
          if(box.isModalOpen()){
            await sleep(400);
            // Description από modal αν δεν το έχουμε ήδη
            if(!item.description){
              const mDesc=document.querySelector('product-myo .product-myo-details-content');
              if(mDesc){const t=mDesc.textContent.trim();if(t)item.description=t;}
            }
            item.option_groups=box.getModalOptions();
            box.closeModal();
            w=0;while(box.isModalOpen()&&w<2000){await sleep(100);w+=100;}
            await sleep(300);
          } else {item.option_groups=[];}
        }
      }
    },

    async run(){
      // Βρίσκω το scrollable container
      const container=document.querySelector('.shell-wrapper');
      if(!container){setSt('❌ Δεν βρέθηκε το shell-wrapper container',0);window.__efoodScraping=false;return {catalog:[],source:'box'};}

      // Pass 1: Αργό scroll + scan σε κάθε βήμα
      setSt('Φορτώνω κατάλογο...',2);
      const itemMap=new Map();
      container.scrollTop=0;
      await sleep(500);

      const totalH=container.scrollHeight;
      const step=200;
      let pos=0;
      while(pos<=totalH+500){
        container.scrollTop=pos;
        await sleep(250);
        box.scanVisible(itemMap);
        const pct=Math.min(8,Math.round(pos/totalH*8));
        setSt(`Φορτώνω... ${itemMap.size} προϊόντα (${Math.round(pos/totalH*100)}%)`,pct);
        pos+=step;
        if(container.scrollTop+container.clientHeight>=container.scrollHeight-10)break;
      }

      // Pass 1b: Κλικ σε κάθε "Μη διαθέσιμα" κουμπί και συλλογή items
      setSt('Συλλέγω μη διαθέσιμα προϊόντα...',9);
      const unavailBtns=document.querySelectorAll('.shop-menu-items-unavailable-wrapper');
      for(const btn of unavailBtns){
        const section=btn.closest('section.shop-menu-items-category');
        const h2=section?section.querySelector('h2.shop-menu-items-category-name'):null;
        const catName=h2?h2.textContent.trim():'Γενικά';
        btn.scrollIntoView({block:'center'});
        await sleep(300);
        btn.click();
        let w=0;
        while(!document.querySelector('unavailable-items-dialog')&&w<2000){await sleep(100);w+=100;}
        if(!document.querySelector('unavailable-items-dialog')){continue;}
        await sleep(300);
        document.querySelectorAll('unavailable-items-dialog .food-product-component').forEach(card=>{
          const nameEl=card.querySelector('.box-typography-body-m-bold');
          const name=nameEl?nameEl.textContent.trim():'';
          if(!name||itemMap.has(name))return;
          let price=null;
          const priceEl=card.querySelector('span.food-item-price');
          if(priceEl){
            const pm=priceEl.textContent.trim().match(/(\d+[,.]\d+)\s*€/);
            if(pm)price=parseFloat(pm[1].replace(',','.'));
          }
          let description=null;
          const descEl=card.querySelector('.food-item-description');
          if(descEl){const t=descEl.textContent.trim();if(t)description=t;}
          itemMap.set(name,{name,price,description,catName,card:null,option_groups:[],notes:'Μη διαθέσιμο προϊόν'});
        });
        const closeBtn=document.querySelector('unavailable-items-dialog button[aria-label="Close"]');
        if(closeBtn)closeBtn.click();
        await sleep(400);
      }

      // Scroll πίσω στην αρχή
      container.scrollTop=0;
      await sleep(500);

      const catalog=box.buildCatalog(itemMap);
      const total=catalog.reduce((s,c)=>s+c.items.length,0);
      setSt(`${catalog.length} κατηγορίες, ${total} προϊόντα — συλλέγω options...`,10);
      await sleep(300);

      // Pass 2: Click για options (μόνο για διαθέσιμα)
      await box.collectOptions(catalog,container);
      return {catalog,source:'box'};
    }
  };

  /* ══════════════════════════════════════════
     STANDALONE SCRAPER (AI-based)
  ══════════════════════════════════════════ */
  const standalone={
    async run(){
      setSt('Διαβάζω σελίδα...',10);
      // Scroll για lazy loading
      let lastH=0,att=0;
      while(att<20){window.scrollTo(0,document.body.scrollHeight);await sleep(400);const h=document.body.scrollHeight;if(h===lastH)break;lastH=h;att++;}
      window.scrollTo(0,0);
      // Εξάγω το innerText (καθαρό κείμενο χωρίς HTML)
      const pageText=document.body.innerText.slice(0,30000);
      const pageTitle=document.title||location.hostname;
      setSt('Στέλνω στο AI για ανάλυση...',30);
      // Στέλνω στο Supabase Edge Function (ίδιο με το catalog_autofill.html)
      const EDGE_FN='https://gxrybwnufjhoymsclxla.supabase.co/functions/v1/extract-catalog';
      const SUPA_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd4cnlid251Zmpob3ltc2NseGxhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODIxMzg0NzksImV4cCI6MjA5NzcxNDQ3OX0.Z5fCjFdp42-sGcNAEZyD22YQdUxSbktlhy3VCMChAPQ';
      const resp=await fetch(EDGE_FN,{
        method:'POST',
        headers:{'Content-Type':'application/json','Authorization':`Bearer ${SUPA_KEY}`},
        body:JSON.stringify({storeName:pageTitle,text:pageText,images:[]})
      });
      if(!resp.ok)throw new Error(`Edge Function error ${resp.status}`);
      const data=await resp.json();
      if(!data.categories)throw new Error('Μη αναμενόμενο schema από AI');
      setSt('✓ AI ανάλυση ολοκληρώθηκε!',95);
      // Μετατροπή στο catalog format
      const catalog=data.categories.map(cat=>({
        name:cat.name,
        items:(cat.items||[]).map(it=>({
          name:it.name,price:it.price,description:it.description,
          option_groups:it.option_groups||[]
        }))
      }));
      return {catalog,source:'standalone'};
    }
  };

  /* ══════════════════════════════════════════
     MAIN
  ══════════════════════════════════════════ */
  async function main(){
    try{
      let result;
      if(PLATFORM==='wolt')       result=await wolt.run();
      else if(PLATFORM==='box')   result=await box.run();
      else                        result=await standalone.run();

      const {catalog,source}=result;
      const totalItems=catalog.reduce((s,c)=>s+c.items.length,0);
      const totalOpts=catalog.reduce((s,c)=>c.items.reduce((ss,it)=>ss+(it.option_groups||[]).reduce((sss,g)=>sss+(g.options||[]).length,0),s),0);

      const output={
        categories:catalog.map(c=>({
          name:c.name,
          items:c.items.map(({btn,card,...rest})=>({
            ...rest,
            confidence:'high',
            notes:null
          }))
        })),
        _ts:Date.now(),
        _source:source,
        _url:location.href
      };

      setSt(`✓ ${totalItems} προϊόντα · ${totalOpts} επιλογές · ${catalog.length} κατηγορίες`,100);

      // Download button
      const bd=document.createElement('div');
      bd.style.marginTop='12px';
      const dl=document.createElement('button');
      dl.textContent='⬇ Κατέβασε JSON';
      dl.style.cssText='background:#f5b800;color:#0f0f0f;border:none;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer;font-size:13px;';
      dl.onclick=function(){
        const blob=new Blob([JSON.stringify(output,null,2)],{type:'application/json'});
        const url=URL.createObjectURL(blob);
        const a=document.createElement('a');
        a.href=url;a.download=source+'_catalog.json';
        document.body.appendChild(a);a.click();document.body.removeChild(a);
        setTimeout(()=>URL.revokeObjectURL(url),2000);
      };
      const cl=document.createElement('button');
      cl.textContent='Κλείσιμο';
      cl.style.cssText='background:#333;color:#fff;border:none;border-radius:8px;padding:8px 14px;font-weight:600;cursor:pointer;font-size:13px;margin-left:6px;';
      cl.onclick=()=>ov.remove();
      bd.appendChild(dl);bd.appendChild(cl);
      ov.appendChild(bd);
      window.__efoodScraping=false;
    }catch(e){
      setSt('❌ Σφάλμα: '+e.message,0);
      console.error(e);
      window.__efoodScraping=false;
    }
  }

  main();
})();
