async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function detectPlatform(url) {
  if (!url) return 'unknown';
  if (url.includes('wolt.com')) return 'wolt';
  if (url.includes('box.gr'))   return 'box';
  if (url.startsWith('http'))   return 'standalone';
  return 'unknown';
}

async function runScraper() {
  const tab = await getCurrentTab();
  const btn = document.getElementById('run-btn');
  const status = document.getElementById('status');

  btn.disabled = true;
  btn.textContent = '⏳ Εκκίνηση...';
  status.textContent = 'Φορτώνω scraper...';

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { window.__efoodScraping = false; }
    });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['scraper.js']
    });
    status.textContent = '✓ Τρέχει! Δες τη σελίδα.';
    btn.textContent = '✓ Εκκινήθηκε';
    setTimeout(() => window.close(), 1500);
  } catch (e) {
    status.textContent = '❌ Σφάλμα: ' + e.message;
    btn.disabled = false;
    btn.textContent = '▶ Εκκίνηση εξαγωγής';
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const tab = await getCurrentTab();
  const platform = detectPlatform(tab.url || '');
  const badge = document.getElementById('platform-badge');
  const note = document.getElementById('note');
  const btn = document.getElementById('run-btn');

  const labels = {
    wolt:       '🟢 Wolt',
    box:        '🔵 Box.gr',
    standalone: '🟡 Standalone σελίδα',
    unknown:    '🔴 Μη υποστηριζόμενη σελίδα'
  };
  const notes = {
    wolt:       'Scraping με DOM + click για option groups',
    box:        'Scraping με DOM + click για option groups',
    standalone: 'AI-based ανάλυση μέσω Edge Function',
    unknown:    'Άνοιξε σελίδα vendor, Wolt ή Box.gr'
  };

  badge.textContent = labels[platform];
  badge.className = `platform-badge ${platform}`;
  note.textContent = notes[platform];

  if (platform !== 'unknown') {
    btn.disabled = false;
    document.getElementById('run-btn').addEventListener('click', runScraper);
  }
});
