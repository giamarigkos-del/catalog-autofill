// popup.js

async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function runScraper() {
  const tab = await getCurrentTab();
  const btn = document.getElementById('run-btn');
  const status = document.getElementById('status');

  // Ελέγχω αν είμαστε στο Wolt
  if (!tab.url || !tab.url.includes('wolt.com')) {
    document.getElementById('main').style.display = 'none';
    document.getElementById('not-wolt').style.display = '';
    return;
  }

  btn.disabled = true;
  btn.textContent = '⏳ Εκκίνηση...';
  status.textContent = 'Φορτώνω scraper...';

  try {
    // Inject το scraper script στη σελίδα
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['scraper.js']
    });
    status.textContent = '✓ Τρέχει! Δες τη σελίδα Wolt.';
    btn.textContent = '✓ Εκκινήθηκε';
  } catch (e) {
    status.textContent = '❌ Σφάλμα: ' + e.message;
    btn.disabled = false;
    btn.textContent = '▶ Εκκίνηση εξαγωγής';
  }
}

// Έλεγχος κατά το άνοιγμα του popup
getCurrentTab().then(tab => {
  if (!tab.url || !tab.url.includes('wolt.com')) {
    document.getElementById('main').style.display = 'none';
    document.getElementById('not-wolt').style.display = '';
  }
});
