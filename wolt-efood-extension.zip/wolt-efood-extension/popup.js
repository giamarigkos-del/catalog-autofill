// popup.js

async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function runScraper() {
  const tab = await getCurrentTab();
  const btn = document.getElementById('run-btn');
  const status = document.getElementById('status');

  // Ελέγχω αν είμαστε στο Wolt
  if (!tab.url || !tab.url.includes('wolt.com')) {
    document.getElementById('main').style.display = 'none';
    document.getElementById('not-wolt').style.display = '';
    return;
  }

  btn.disabled = true;
  btn.textContent = '⏳ Εκκίνηση...';
  status.textContent = 'Φορτώνω scraper...';

  try {
    // Reset του scraping flag πριν το inject
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { window.__efoodScraping = false; }
    });
    // Inject το scraper script στη σελίδα
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['scraper.js']
    });
    status.textContent = '✓ Τρέχει! Δες τη σελίδα Wolt.';
    btn.textContent = '✓ Εκκινήθηκε';
    setTimeout(() => window.close(), 1500);
  } catch (e) {
    status.textContent = '❌ Σφάλμα: ' + e.message;
    btn.disabled = false;
    btn.textContent = '▶ Εκκίνηση εξαγωγής';
  }
}

// Αρχικοποίηση όταν φορτωθεί το DOM
document.addEventListener('DOMContentLoaded', () => {
  // Event listener για το κουμπί (αντί για inline onclick)
  document.getElementById('run-btn').addEventListener('click', runScraper);

  // Έλεγχος αν είμαστε στο Wolt
  getCurrentTab().then(tab => {
    if (!tab.url || !tab.url.includes('wolt.com')) {
      document.getElementById('main').style.display = 'none';
      document.getElementById('not-wolt').style.display = '';
    }
  });
});
